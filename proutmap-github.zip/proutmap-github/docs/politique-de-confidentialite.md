# Politique de confidentialité — Prout Map

*Dernière mise à jour : [DATE]*

Prout Map est éditée par **[NOM DE LA SOCIÉTÉ / DE L'ÉDITEUR]**, [ADRESSE], contact : [E-MAIL].

## Données collectées
- **Compte** : identifiant fourni par Google ou Apple, nom affiché, adresse e-mail (si transmise par le fournisseur).
- **Prouts** : position GPS au moment de l'enregistrement, date, type, notes de 1 à 5, texte libre facultatif, nom ou compte de la « victime » éventuelle.
- **Social** : liste d'amis, ligues rejointes.
- **Notifications** : jeton technique de notification de ton appareil.

La position n'est lue **que** quand tu enregistres un prout, ouvres la carte ou utilises le détecteur. Aucun suivi en arrière-plan.

## Mes lieux
Les lieux que tu enregistres (Maison, Boulot…) restent **uniquement sur ton téléphone**. Ils ne sont jamais envoyés au serveur ni montrés à tes amis.

## Micro (détecteur de prouts)
Le micro n'est utilisé **que** si tu lances le détecteur, et seulement tant que son écran est ouvert.
Le son est analysé en direct sur ton téléphone (niveau sonore et part de graves) : il n'est **jamais enregistré, conservé ni envoyé**.
Pendant un compte à rebours, l'appli demande au serveur s'il y a eu un prout déclaré à moins de 50 m dans les 2 dernières minutes.
Le serveur répond seulement « oui » ou « non », sans nom ni position de qui que ce soit.

## Sons perso (Bande son)
Les sons que tu enregistres ou importes restent **uniquement sur ton téléphone** : ils ne sont jamais envoyés au serveur. Ils ne quittent ton téléphone que si **tu** choisis de les envoyer (WhatsApp, SMS…). Tu peux les supprimer à tout moment (« Revenir au son d'origine »).

## Utilisation
Ces données servent uniquement à faire fonctionner l'appli : afficher la carte, les statistiques, les classements et prévenir un ami quand tu lui « pètes dessus ». Pas de publicité, pas de revente.

## Qui voit quoi
- Tes prouts sont visibles par toi et par tes amis acceptés.
- Un prout lâché « sur » un ami est visible par cet ami.
- Dans une ligue, les autres membres voient ton pseudo et ton **nombre** de prouts, pas leur position.

## Hébergement
Données hébergées par Supabase (région Union européenne). Notifications transmises via le service d'Expo et Apple / Google.

## Durée de conservation et suppression
Les données sont conservées tant que ton compte existe. Le bouton **Moi → Supprimer mon compte** efface immédiatement et définitivement ton compte et toutes tes données.

## Tes droits (RGPD)
Accès, rectification, effacement, portabilité, opposition : écris à [E-MAIL]. Tu peux aussi saisir la CNIL (www.cnil.fr).
