-- =====================================================================
-- Prout Map — Détecteur de prouts (micro)
-- À exécuter dans Supabase > SQL Editor APRÈS 0001_init.sql
-- =====================================================================

-- Accélère la recherche des prouts récents
create index if not exists farts_created_idx on public.farts (created_at desc);

-- « Quelqu'un a-t-il déclaré un prout près d'ici à l'instant ? »
-- Compte TOUS les utilisateurs (amis ou pas), mais ne renvoie que oui / non :
-- ni nom, ni position exacte, ni nombre. Limité aux 2 dernières minutes et à 100 m
-- pour qu'on ne puisse pas s'en servir pour fouiller l'historique des autres.
create or replace function public.fart_declared_nearby(
  p_lat double precision,
  p_lng double precision,
  p_seconds integer default 60,
  p_radius_m double precision default 50
) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1
    from public.farts f
    where f.created_at >= now() - make_interval(secs => least(greatest(p_seconds, 1), 120))
      and f.lat between p_lat - 0.001 and p_lat + 0.001          -- pré-filtre ~110 m
      and sqrt(
            power((f.lat - p_lat) * 111320, 2)
          + power((f.lng - p_lng) * 111320 * cos(radians(p_lat)), 2)
          ) <= least(greatest(p_radius_m, 1), 100)
  );
$$;

revoke execute on function public.fart_declared_nearby(double precision, double precision, integer, double precision) from public, anon;
grant execute on function public.fart_declared_nearby(double precision, double precision, integer, double precision) to authenticated;
