/**
 * 💾 Sauvegarde / restauration : sonothèque (fichiers + attributions), lieux et réglages
 * du détecteur dans UN fichier, que l'on s'envoie (WhatsApp, e-mail…) pour le retrouver
 * dans une autre version de l'appli ou sur un autre téléphone.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as DocumentPicker from 'expo-document-picker';
import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';

import { listPlaces, restorePlaces, type Place } from './places';
import { getSoundPrefs, restoreSounds, type SoundPrefs } from './sounds';

const DETECTOR_KEY = 'proutmap-detector-v1';
const FORMAT = 'proutmap-sauvegarde';

type Backup = {
  format: typeof FORMAT;
  version: 1;
  createdAt: string;
  sounds: { id: string; label: string; ext: string; data: string }[];
  slots: SoundPrefs['slots'];
  places: Place[];
  detector: unknown;
};

export type BackupSummary = { sounds: number; places: number };

function safeSize(uri: string) {
  try {
    return new File(uri).size ?? -1;
  } catch {
    return -1;
  }
}

/** Crée le fichier de sauvegarde puis ouvre le menu de partage */
export async function createAndShareBackup(): Promise<BackupSummary> {
  const prefs = await getSoundPrefs();
  const sounds: Backup['sounds'] = [];
  for (const it of prefs.library) {
    try {
      const f = new File(it.file);
      if (!f.exists) continue;
      sounds.push({
        id: it.id,
        label: it.label,
        ext: it.file.split('.').pop()?.toLowerCase() || 'm4a',
        data: await f.base64(),
      });
    } catch {
      // Un son illisible ne bloque pas toute la sauvegarde
    }
  }
  const places = await listPlaces();
  let detector: unknown = null;
  try {
    const raw = await AsyncStorage.getItem(DETECTOR_KEY);
    detector = raw ? JSON.parse(raw) : null;
  } catch {}

  const backup: Backup = {
    format: FORMAT,
    version: 1,
    createdAt: new Date().toISOString(),
    sounds,
    slots: prefs.slots,
    places,
    detector,
  };

  const day = new Date().toISOString().slice(0, 10);
  const out = new File(Paths.cache, `ProutMap-sauvegarde-${day}.json`);
  if (out.exists) out.delete();
  out.create();
  await out.write(JSON.stringify(backup));

  if (!(await Sharing.isAvailableAsync())) throw new Error("Le partage de fichiers n'est pas disponible sur ce téléphone.");
  await Sharing.shareAsync(out.uri, {
    mimeType: 'application/json',
    dialogTitle: 'Ma sauvegarde Prout Map',
  });
  return { sounds: sounds.length, places: places.length };
}

/** Choisit un fichier de sauvegarde et le restaure. null = annulé */
export async function pickAndRestoreBackup(): Promise<BackupSummary | null> {
  const res = await DocumentPicker.getDocumentAsync({
    type: ['application/json', 'text/plain', 'application/octet-stream', '*/*'],
    copyToCacheDirectory: true,
  });
  if (res.canceled) return null;
  let backup: Backup;
  try {
    backup = JSON.parse(await new File(res.assets[0].uri).text());
  } catch {
    throw new Error("Ce fichier n'est pas une sauvegarde Prout Map.");
  }
  if (backup?.format !== FORMAT) throw new Error("Ce fichier n'est pas une sauvegarde Prout Map.");

  // 1. Les sons : on recrée chaque fichier dans l'appli (sauf ceux déjà présents : même nom, même taille)
  const existing = (await getSoundPrefs()).library.map((x) => ({ label: x.label, size: safeSize(x.file) }));
  const items: { oldId: string; file: string; label: string }[] = [];
  for (const s of backup.sounds ?? []) {
    try {
      const bytes = Math.floor((String(s.data).length * 3) / 4) - (String(s.data).match(/=+$/)?.[0].length ?? 0);
      const dup = existing.find((e) => e.label === s.label && e.size === bytes);
      if (dup) {
        items.push({ oldId: s.id, file: '', label: s.label }); // déjà là : on garde juste les attributions
        continue;
      }
      const ext = String(s.ext || 'm4a').replace(/[^a-z0-9]/gi, '').toLowerCase() || 'm4a';
      const f = new File(Paths.document, `son-r${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}.${ext}`);
      f.create();
      await f.write(s.data, { encoding: 'base64' });
      items.push({ oldId: s.id, file: f.uri, label: s.label });
    } catch {}
  }
  const sounds = await restoreSounds(items, backup.slots ?? {});

  // 2. Les lieux
  const places = await restorePlaces(backup.places ?? []);

  // 3. Les réglages du détecteur
  if (backup.detector) await AsyncStorage.setItem(DETECTOR_KEY, JSON.stringify(backup.detector)).catch(() => {});

  return { sounds, places };
}
