/**
 * 🎵 Bande son de l'appli.
 *
 * Chaque moment de l'appli a un « emplacement » (slot) : les 5 types de prouts, le « Oups je t'ai
 * pété dessus », le son après la sirène du détecteur, le son quand le coupable assume.
 * Chaque emplacement joue son son d'origine, ou un son perso (enregistré dans l'appli ou importé).
 * Les sons perso restent sur le téléphone ; on peut les envoyer à qui on veut (WhatsApp…).
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createAudioPlayer, setAudioModeAsync, type AudioPlayer } from 'expo-audio';
import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import * as Speech from 'expo-speech';

import { KINDS, type FartKind } from './types';

// Bruitages générés pour l'appli (libres de droits)
const SOURCES: Record<FartKind, number> = {
  silencieux: require('@/assets/sounds/silencieux.wav'),
  classique: require('@/assets/sounds/classique.wav'),
  tonitruant: require('@/assets/sounds/tonitruant.wav'),
  foireux: require('@/assets/sounds/foireux.wav'),
  en_rafale: require('@/assets/sounds/en_rafale.wav'),
};
const ALARM = require('@/assets/sounds/alarme.wav');
export const ALARM_SEC = 2;
/** Un son perso est coupé au-delà */
export const CUSTOM_MAX_SEC = 6;

// ---- Les emplacements de la bande son ------------------------------------------
export type SoundSlot = FartKind | 'oups' | 'alarme' | 'assume';

export type SlotInfo = {
  slot: SoundSlot;
  emoji: string;
  title: string;
  when: string;
  /** Texte du son d'origine (null = silence par défaut) */
  original: string | null;
};

export const SLOTS: SlotInfo[] = [
  ...KINDS.map((k) => ({
    slot: k.value as SoundSlot,
    emoji: k.emoji,
    title: k.badge ? `${k.label} · ${k.badge}` : k.label,
    when: 'Quand tu enregistres ce type de prout',
    original: 'Bruitage Prout Map',
  })),
  {
    slot: 'oups',
    emoji: '😈',
    title: "« Oups je t'ai pété dessus !! xD »",
    when: 'Quand tu lâches un prout sur une victime',
    original: null,
  },
  {
    slot: 'alarme',
    emoji: '🚨',
    title: 'Après la sirène du détecteur',
    when: 'Quand personne n’assume',
    original: '🤖 « Mais qui c’est qui a pété ?! »',
  },
  {
    slot: 'assume',
    emoji: '🙋',
    title: 'Coupable démasqué',
    when: 'Quand quelqu’un se déclare pendant le compte à rebours',
    original: null,
  },
];
export const slotInfo = (s: SoundSlot) => SLOTS.find((x) => x.slot === s)!;

/** Un son perso (enregistré dans l'appli ou importé) */
export type SoundItem = { id: string; file: string; label: string };
/**
 * Pour chaque emplacement : la collection de sons perso et le choix actuel
 * 'original' = son d'origine (voix robot pour l'alarme, silence pour Oups / Coupable),
 * 'random' = un de mes sons au hasard, 'off' = rien (alarme), sinon l'id d'un son.
 */
export type SlotPrefs = { items: SoundItem[]; active: string };
export type SoundPrefs = { slots: Partial<Record<SoundSlot, SlotPrefs>> };

export const MAX_SOUNDS_PER_SLOT = 20;
const KEY = 'proutmap-sounds-v2';
const V1_KEY = 'proutmap-sounds-v1'; // un seul son par emplacement
const V0_KEY = 'proutmap-alarm-voice-v1'; // voix de l'alarme seule
let prefs: SoundPrefs = { slots: {} };
let loaded = false;

const newId = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

export function slotPrefs(slot: SoundSlot, p: SoundPrefs = prefs): SlotPrefs {
  return p.slots[slot] ?? { items: [], active: 'original' };
}

async function migrate(): Promise<SoundPrefs> {
  const out: SoundPrefs = { slots: {} };
  try {
    const v1raw = await AsyncStorage.getItem(V1_KEY);
    if (v1raw) {
      const v1 = JSON.parse(v1raw) as {
        custom: Partial<Record<SoundSlot, { file: string; label: string }>>;
        alarmMode?: 'robot' | 'perso' | 'off';
      };
      for (const [slot, c] of Object.entries(v1.custom ?? {})) {
        if (!c) continue;
        const id = newId();
        const active = slot === 'alarme' ? (v1.alarmMode === 'perso' ? id : (v1.alarmMode === 'off' ? 'off' : 'original')) : id;
        out.slots[slot as SoundSlot] = { items: [{ id, file: c.file, label: c.label }], active };
      }
      if (v1.alarmMode === 'off' && !out.slots.alarme) out.slots.alarme = { items: [], active: 'off' };
      return out;
    }
    const v0raw = await AsyncStorage.getItem(V0_KEY);
    if (v0raw) {
      const v0 = JSON.parse(v0raw);
      const items = v0.file ? [{ id: newId(), file: v0.file, label: v0.label ?? 'Mon son' }] : [];
      out.slots.alarme = {
        items,
        active: v0.mode === 'perso' && items[0] ? items[0].id : v0.mode === 'off' ? 'off' : 'original',
      };
    }
  } catch {}
  return out;
}

export async function getSoundPrefs(): Promise<SoundPrefs> {
  if (loaded) return prefs;
  try {
    const raw = await AsyncStorage.getItem(KEY);
    prefs = raw ? JSON.parse(raw) : await migrate();
  } catch {}
  // Fichiers disparus (appli réinstallée…) : on les oublie
  for (const [slot, sp] of Object.entries(prefs.slots)) {
    if (!sp) continue;
    sp.items = sp.items.filter((it) => safeExists(it.file));
    if (!['original', 'random', 'off'].includes(sp.active) && !sp.items.some((it) => it.id === sp.active)) {
      sp.active = 'original';
    }
    if (sp.active === 'off' && slot !== 'alarme') sp.active = 'original';
  }
  loaded = true;
  await savePrefs();
  return prefs;
}

async function savePrefs() {
  await AsyncStorage.setItem(KEY, JSON.stringify(prefs)).catch(() => {});
}

function editSlot(slot: SoundSlot): SlotPrefs {
  const sp = slotPrefs(slot);
  prefs.slots[slot] = sp;
  return sp;
}

function safeExists(uri: string) {
  try {
    return new File(uri).exists;
  } catch {
    return false;
  }
}

function removeFile(uri?: string | null) {
  try {
    if (uri) {
      const f = new File(uri);
      if (f.exists) f.delete();
    }
  } catch {}
}

/** Ajoute un son (enregistrement ou fichier importé) à la collection, et le choisit */
export async function addSound(slot: SoundSlot, sourceUri: string, ext: string, label: string) {
  await getSoundPrefs();
  const sp = editSlot(slot);
  if (sp.items.length >= MAX_SOUNDS_PER_SLOT) {
    throw new Error(`Maximum ${MAX_SOUNDS_PER_SLOT} sons ici : supprimes-en un pour faire de la place.`);
  }
  const clean = ext.replace(/[^a-z0-9]/gi, '').toLowerCase() || 'm4a';
  const id = newId();
  const dest = new File(Paths.document, `son-${slot}-${id}.${clean}`);
  new File(sourceUri).copySync(dest, { overwrite: true });
  sp.items.push({ id, file: dest.uri, label: label.trim().slice(0, 40) || `Son n°${sp.items.length + 1}` });
  sp.active = id;
  await savePrefs();
  return id;
}

export async function renameSound(slot: SoundSlot, id: string, label: string) {
  await getSoundPrefs();
  const it = editSlot(slot).items.find((x) => x.id === id);
  if (it && label.trim()) it.label = label.trim().slice(0, 40);
  await savePrefs();
}

export async function deleteSound(slot: SoundSlot, id: string) {
  await getSoundPrefs();
  const sp = editSlot(slot);
  removeFile(sp.items.find((x) => x.id === id)?.file);
  sp.items = sp.items.filter((x) => x.id !== id);
  if (sp.active === id || (sp.active === 'random' && sp.items.length === 0)) sp.active = 'original';
  await savePrefs();
}

/** Choix du son joué : 'original', 'random', 'off' (alarme) ou l'id d'un son */
export async function setActive(slot: SoundSlot, active: string) {
  await getSoundPrefs();
  editSlot(slot).active = active;
  await savePrefs();
}

/** Vrai si cet emplacement joue un son perso (choisi ou au hasard) */
export const isCustom = (slot: SoundSlot, p: SoundPrefs = prefs) => {
  const sp = slotPrefs(slot, p);
  return sp.items.length > 0 && sp.active !== 'original' && sp.active !== 'off';
};

/** Envoie un son par WhatsApp, Messenger, SMS… (on choisit le groupe ou la conversation) */
export async function shareSound(slot: SoundSlot, id: string) {
  const p = await getSoundPrefs();
  const it = slotPrefs(slot, p).items.find((x) => x.id === id);
  if (!it || !(await Sharing.isAvailableAsync())) return false;
  const ext = it.file.split('.').pop()?.toLowerCase();
  const mimeType =
    ext === 'wav' ? 'audio/wav' : ext === 'mp3' ? 'audio/mpeg' : ext === 'ogg' || ext === 'opus' ? 'audio/ogg' : 'audio/mp4';
  await Sharing.shareAsync(it.file, { mimeType, dialogTitle: `Mon son Prout Map : ${it.label}` });
  return true;
}

// ---- Lecture -----------------------------------------------------------------
let player: AudioPlayer | null = null;
let modeApplied = false;
let micOn = false;

/** Le détecteur s'abonne ici pour ignorer le micro pendant nos propres sons */
let onOwnSound: ((sec: number) => void) | null = null;
export function setOwnSoundListener(fn: ((sec: number) => void) | null) {
  onOwnSound = fn;
}

async function applyMode() {
  // Joue même si le téléphone est en mode silencieux (c'est le but !)
  // allowsRecording garde le micro ouvert pour le détecteur, le son reste sur le haut-parleur
  await setAudioModeAsync({
    playsInSilentMode: true,
    allowsRecording: micOn,
    shouldRouteThroughEarpiece: false,
  });
  modeApplied = true;
}

/** Ouvre ou ferme l'accès micro (détecteur, enregistrement d'un son) */
export async function setMicMode(on: boolean) {
  micOn = on;
  await applyMode().catch(() => {});
}

/** Joue une source (son d'origine ou fichier perso), coupée au bout de CUSTOM_MAX_SEC */
function play(source: number | { uri: string }) {
  onOwnSound?.(CUSTOM_MAX_SEC + 1);
  player?.remove();
  const p = createAudioPlayer(source);
  player = p;
  p.volume = 1;
  p.play();
  setTimeout(() => {
    try {
      if (player === p) p.pause();
    } catch {}
  }, CUSTOM_MAX_SEC * 1000);
}

/** Joue le son d'un emplacement selon le choix (perso, au hasard, d'origine…) */
export async function playSlot(slot: SoundSlot, opts: { forceOriginal?: boolean } = {}) {
  try {
    if (!modeApplied) await applyMode();
    const sp = slotPrefs(slot, await getSoundPrefs());
    let item: SoundItem | undefined;
    if (!opts.forceOriginal) {
      if (sp.active === 'off') return;
      if (sp.active === 'random') item = sp.items[Math.floor(Math.random() * sp.items.length)];
      else item = sp.items.find((x) => x.id === sp.active);
    }
    if (item) return play({ uri: item.file });
    if (slot === 'alarme') return sayWhoFarted();
    if (slot in SOURCES) return play(SOURCES[slot as FartKind]);
    // oups / coupable : pas de son d'origine
  } catch {
    // Le son est un bonus : on ne bloque jamais l'appli pour ça
  }
}

/** Écoute d'un son précis de la collection */
export async function playItem(slot: SoundSlot, id: string) {
  try {
    if (!modeApplied) await applyMode();
    const it = slotPrefs(slot, await getSoundPrefs()).items.find((x) => x.id === id);
    if (it) play({ uri: it.file });
  } catch {}
}

export const playFart = (kind: FartKind) => playSlot(kind);

/** Durée totale « sirène + son » pendant laquelle le détecteur se bouche les oreilles */
export function alarmTotalSec() {
  return slotPrefs('alarme').active === 'off' ? ALARM_SEC + 1.5 : ALARM_SEC + CUSTOM_MAX_SEC + 1;
}

/** Sirène de 2 secondes au volume maximum de l'appli, puis le son choisi */
export async function playAlarm() {
  try {
    if (!modeApplied) await applyMode();
    await getSoundPrefs();
    onOwnSound?.(alarmTotalSec());
    player?.remove();
    player = createAudioPlayer(ALARM);
    player.volume = 1;
    player.play();
    setTimeout(() => playSlot('alarme'), ALARM_SEC * 1000 + 150);
  } catch {}
}

/** Voix aiguë et un peu traînante = effet « dessin animé » */
export function sayWhoFarted() {
  try {
    onOwnSound?.(3.5); // le détecteur ne doit pas se déclencher sur sa propre voix
    Speech.stop();
    Speech.speak("Mais qui c'est qui a pété ?!", { language: 'fr-FR', pitch: 1.6, rate: 0.9, volume: 1 });
  } catch {}
}

/** Remet le mode audio normal (après un enregistrement) */
export async function resetAudioMode() {
  await applyMode().catch(() => {});
}

/** Résumé du choix actuel, pour les listes */
export const slotLabel = (slot: SoundSlot, p: SoundPrefs) => {
  const sp = slotPrefs(slot, p);
  if (sp.active === 'off') return '🔇 Rien';
  if (sp.active === 'random' && sp.items.length) return `🎲 Au hasard parmi ${sp.items.length} sons`;
  const it = sp.items.find((x) => x.id === sp.active);
  if (it) return `🎤 ${it.label}`;
  return slotInfo(slot).original ?? '🔇 Pas de son';
};
