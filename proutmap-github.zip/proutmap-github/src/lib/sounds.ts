/**
 * 🎵 Bande son de l'appli.
 *
 * Chaque moment de l'appli a un « emplacement » (slot) : les 5 types de prouts, le « Oups je t'ai
 * pété dessus », le son après la sirène du détecteur, le son quand le coupable assume.
 * Chaque emplacement joue son son d'origine, ou un son perso (enregistré dans l'appli ou importé).
 * Les sons perso restent sur le téléphone ; on peut les envoyer à qui on veut (WhatsApp…).
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createAudioPlayer, setAudioModeAsync, type AudioPlayer } from 'expo-audio';
import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import * as Speech from 'expo-speech';

import { KINDS, type FartKind } from './types';

// Bruitages générés pour l'appli (libres de droits)
const SOURCES: Record<FartKind, number> = {
  silencieux: require('@/assets/sounds/silencieux.wav'),
  classique: require('@/assets/sounds/classique.wav'),
  tonitruant: require('@/assets/sounds/tonitruant.wav'),
  foireux: require('@/assets/sounds/foireux.wav'),
  en_rafale: require('@/assets/sounds/en_rafale.wav'),
};
const ALARM = require('@/assets/sounds/alarme.wav');
export const ALARM_SEC = 2;
/** Un son perso est coupé au-delà */
export const CUSTOM_MAX_SEC = 6;

// ---- Les emplacements de la bande son ------------------------------------------
export type SoundSlot = FartKind | 'oups' | 'alarme' | 'assume';

export type SlotInfo = {
  slot: SoundSlot;
  emoji: string;
  title: string;
  when: string;
  /** Texte du son d'origine (null = silence par défaut) */
  original: string | null;
};

export const SLOTS: SlotInfo[] = [
  ...KINDS.map((k) => ({
    slot: k.value as SoundSlot,
    emoji: k.emoji,
    title: k.badge ? `${k.label} · ${k.badge}` : k.label,
    when: 'Quand tu enregistres ce type de prout',
    original: 'Bruitage Prout Map',
  })),
  {
    slot: 'oups',
    emoji: '😈',
    title: "« Oups je t'ai pété dessus !! xD »",
    when: 'Quand tu lâches un prout sur une victime',
    original: null,
  },
  {
    slot: 'alarme',
    emoji: '🚨',
    title: 'Après la sirène du détecteur',
    when: 'Quand personne n’assume',
    original: '🤖 « Mais qui c’est qui a pété ?! »',
  },
  {
    slot: 'assume',
    emoji: '🙋',
    title: 'Coupable démasqué',
    when: 'Quand quelqu’un se déclare pendant le compte à rebours',
    original: null,
  },
];
export const slotInfo = (s: SoundSlot) => SLOTS.find((x) => x.slot === s)!;

type Custom = { file: string; label: string };
export type SoundPrefs = {
  custom: Partial<Record<SoundSlot, Custom>>;
  /** Pour l'alarme : son d'origine (voix robot), son perso, ou rien */
  alarmMode: 'robot' | 'perso' | 'off';
};

const KEY = 'proutmap-sounds-v1';
const OLD_VOICE_KEY = 'proutmap-alarm-voice-v1'; // ancienne version (voix de l'alarme seule)
let prefs: SoundPrefs = { custom: {}, alarmMode: 'robot' };
let loaded = false;

export async function getSoundPrefs(): Promise<SoundPrefs> {
  if (loaded) return prefs;
  try {
    const raw = await AsyncStorage.getItem(KEY);
    if (raw) prefs = { ...prefs, ...JSON.parse(raw) };
    else {
      // Reprise des réglages de la version précédente
      const old = await AsyncStorage.getItem(OLD_VOICE_KEY);
      if (old) {
        const v = JSON.parse(old);
        prefs = {
          custom: v.file ? { alarme: { file: v.file, label: v.label ?? 'Mon son' } } : {},
          alarmMode: v.mode ?? 'robot',
        };
      }
    }
  } catch {}
  // Fichiers disparus (appli réinstallée…) : on les oublie
  for (const [slot, c] of Object.entries(prefs.custom)) {
    if (!c || !safeExists(c.file)) delete prefs.custom[slot as SoundSlot];
  }
  if (prefs.alarmMode === 'perso' && !prefs.custom.alarme) prefs.alarmMode = 'robot';
  loaded = true;
  return prefs;
}

async function savePrefs() {
  await AsyncStorage.setItem(KEY, JSON.stringify(prefs)).catch(() => {});
}

function safeExists(uri: string) {
  try {
    return new File(uri).exists;
  } catch {
    return false;
  }
}

function removeFile(uri?: string | null) {
  try {
    if (uri) {
      const f = new File(uri);
      if (f.exists) f.delete();
    }
  } catch {}
}

/** Copie un son (enregistrement ou fichier importé) dans l'appli et l'utilise pour cet emplacement */
export async function setCustomSound(slot: SoundSlot, sourceUri: string, ext: string, label: string) {
  await getSoundPrefs();
  const clean = ext.replace(/[^a-z0-9]/gi, '').toLowerCase() || 'm4a';
  const dest = new File(Paths.document, `son-${slot}-${Date.now()}.${clean}`);
  new File(sourceUri).copySync(dest, { overwrite: true });
  removeFile(prefs.custom[slot]?.file);
  prefs.custom[slot] = { file: dest.uri, label: label.trim().slice(0, 40) || 'Mon son' };
  if (slot === 'alarme') prefs.alarmMode = 'perso';
  await savePrefs();
}

/** Revient au son d'origine */
export async function resetSlot(slot: SoundSlot) {
  await getSoundPrefs();
  removeFile(prefs.custom[slot]?.file);
  delete prefs.custom[slot];
  if (slot === 'alarme' && prefs.alarmMode === 'perso') prefs.alarmMode = 'robot';
  await savePrefs();
}

export async function setAlarmMode(mode: SoundPrefs['alarmMode']) {
  await getSoundPrefs();
  prefs.alarmMode = mode === 'perso' && !prefs.custom.alarme ? 'robot' : mode;
  await savePrefs();
}

/** Envoie le son perso par WhatsApp, Messenger, SMS… (on choisit le groupe ou la conversation) */
export async function shareSlot(slot: SoundSlot) {
  const p = await getSoundPrefs();
  const c = p.custom[slot];
  if (!c) return false;
  if (!(await Sharing.isAvailableAsync())) return false;
  const ext = c.file.split('.').pop()?.toLowerCase();
  const mimeType = ext === 'wav' ? 'audio/wav' : ext === 'mp3' ? 'audio/mpeg' : ext === 'ogg' || ext === 'opus' ? 'audio/ogg' : 'audio/mp4';
  await Sharing.shareAsync(c.file, {
    mimeType,
    dialogTitle: `Mon son Prout Map : ${slotInfo(slot).title}`,
  });
  return true;
}

// ---- Lecture -----------------------------------------------------------------
let player: AudioPlayer | null = null;
let modeApplied = false;
let micOn = false;

/** Le détecteur s'abonne ici pour ignorer le micro pendant nos propres sons */
let onOwnSound: ((sec: number) => void) | null = null;
export function setOwnSoundListener(fn: ((sec: number) => void) | null) {
  onOwnSound = fn;
}

async function applyMode() {
  // Joue même si le téléphone est en mode silencieux (c'est le but !)
  // allowsRecording garde le micro ouvert pour le détecteur, le son reste sur le haut-parleur
  await setAudioModeAsync({
    playsInSilentMode: true,
    allowsRecording: micOn,
    shouldRouteThroughEarpiece: false,
  });
  modeApplied = true;
}

/** Ouvre ou ferme l'accès micro (détecteur, enregistrement d'un son) */
export async function setMicMode(on: boolean) {
  micOn = on;
  await applyMode().catch(() => {});
}

/** Joue une source (son d'origine ou fichier perso), coupée au bout de CUSTOM_MAX_SEC */
function play(source: number | { uri: string }) {
  onOwnSound?.(CUSTOM_MAX_SEC + 1);
  player?.remove();
  const p = createAudioPlayer(source);
  player = p;
  p.volume = 1;
  p.play();
  setTimeout(() => {
    try {
      if (player === p) p.pause();
    } catch {}
  }, CUSTOM_MAX_SEC * 1000);
}

/** Joue le son d'un emplacement (perso s'il existe, sinon celui d'origine) */
export async function playSlot(slot: SoundSlot, opts: { forceOriginal?: boolean } = {}) {
  try {
    if (!modeApplied) await applyMode();
    const p = await getSoundPrefs();
    const c = opts.forceOriginal ? undefined : p.custom[slot];
    if (slot === 'alarme') {
      if (opts.forceOriginal) return sayWhoFarted();
      if (p.alarmMode === 'off') return;
      if (p.alarmMode === 'perso' && c) return play({ uri: c.file });
      return sayWhoFarted();
    }
    if (c) return play({ uri: c.file });
    if (slot in SOURCES) return play(SOURCES[slot as FartKind]);
    // oups / assume : pas de son d'origine
  } catch {
    // Le son est un bonus : on ne bloque jamais l'appli pour ça
  }
}

export const playFart = (kind: FartKind) => playSlot(kind);

/** Durée totale « sirène + son » pendant laquelle le détecteur se bouche les oreilles */
export function alarmTotalSec() {
  return prefs.alarmMode === 'off' ? ALARM_SEC + 1.5 : ALARM_SEC + CUSTOM_MAX_SEC + 1;
}

/** Sirène de 2 secondes au volume maximum de l'appli, puis le son choisi */
export async function playAlarm() {
  try {
    if (!modeApplied) await applyMode();
    await getSoundPrefs();
    onOwnSound?.(alarmTotalSec());
    player?.remove();
    player = createAudioPlayer(ALARM);
    player.volume = 1;
    player.play();
    setTimeout(() => playSlot('alarme'), ALARM_SEC * 1000 + 150);
  } catch {}
}

/** Voix aiguë et un peu traînante = effet « dessin animé » */
export function sayWhoFarted() {
  try {
    onOwnSound?.(3.5); // le détecteur ne doit pas se déclencher sur sa propre voix
    Speech.stop();
    Speech.speak("Mais qui c'est qui a pété ?!", { language: 'fr-FR', pitch: 1.6, rate: 0.9, volume: 1 });
  } catch {}
}

/** Remet le mode audio normal (après un enregistrement) */
export async function resetAudioMode() {
  await applyMode().catch(() => {});
}

export const slotLabel = (s: SoundSlot, p: SoundPrefs) => {
  if (s === 'alarme' && p.alarmMode === 'off') return '🔇 Rien';
  const c = p.custom[s];
  if (c && (s !== 'alarme' || p.alarmMode === 'perso')) return `🎤 ${c.label}`;
  return slotInfo(s).original ?? '🔇 Pas de son';
};

