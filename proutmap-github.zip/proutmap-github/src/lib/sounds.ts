import { createAudioPlayer, setAudioModeAsync, type AudioPlayer } from 'expo-audio';

import type { FartKind } from './types';

// Bruitages générés pour l'appli (libres de droits)
const SOURCES: Record<FartKind, number> = {
  silencieux: require('@/assets/sounds/silencieux.wav'),
  classique: require('@/assets/sounds/classique.wav'),
  tonitruant: require('@/assets/sounds/tonitruant.wav'),
  foireux: require('@/assets/sounds/foireux.wav'),
  en_rafale: require('@/assets/sounds/en_rafale.wav'),
};
const ALARM = require('@/assets/sounds/alarme.wav');
export const ALARM_SEC = 2;

let player: AudioPlayer | null = null;
let alarmPlayer: AudioPlayer | null = null;
let modeApplied = false;
let micOn = false;

/** Le détecteur s'abonne ici pour ignorer le micro pendant nos propres sons */
let onOwnSound: ((sec: number) => void) | null = null;
export function setOwnSoundListener(fn: ((sec: number) => void) | null) {
  onOwnSound = fn;
}

async function applyMode() {
  // Joue même si le téléphone est en mode silencieux (c'est le but !)
  // allowsRecording garde le micro ouvert pour le détecteur, le son reste sur le haut-parleur
  await setAudioModeAsync({
    playsInSilentMode: true,
    allowsRecording: micOn,
    shouldRouteThroughEarpiece: false,
  });
  modeApplied = true;
}

/** Ouvre ou ferme l'accès micro (détecteur de prouts) */
export async function setMicMode(on: boolean) {
  micOn = on;
  await applyMode().catch(() => {});
}

export async function playFart(kind: FartKind) {
  try {
    if (!modeApplied) await applyMode();
    onOwnSound?.(3);
    player?.remove();
    player = createAudioPlayer(SOURCES[kind]);
    player.play();
  } catch {
    // Le son est un bonus : on ne bloque jamais l'appli pour ça
  }
}

/** Sirène de 2 secondes, volume maximum de l'appli */
export async function playAlarm() {
  try {
    if (!modeApplied) await applyMode();
    onOwnSound?.(ALARM_SEC + 1.5);
    alarmPlayer?.remove();
    alarmPlayer = createAudioPlayer(ALARM);
    alarmPlayer.volume = 1;
    alarmPlayer.play();
  } catch {}
}
