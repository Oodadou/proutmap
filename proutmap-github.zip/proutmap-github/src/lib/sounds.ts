import { createAudioPlayer, setAudioModeAsync, type AudioPlayer } from 'expo-audio';
import * as Speech from 'expo-speech';

import type { FartKind } from './types';

// Bruitages générés pour l'appli (libres de droits)
const SOURCES: Record<FartKind, number> = {
  silencieux: require('@/assets/sounds/silencieux.wav'),
  classique: require('@/assets/sounds/classique.wav'),
  tonitruant: require('@/assets/sounds/tonitruant.wav'),
  foireux: require('@/assets/sounds/foireux.wav'),
  en_rafale: require('@/assets/sounds/en_rafale.wav'),
};
const ALARM = require('@/assets/sounds/alarme.wav');
export const ALARM_SEC = 2;

let player: AudioPlayer | null = null;
let alarmPlayer: AudioPlayer | null = null;
let modeApplied = false;
let micOn = false;

/** Le détecteur s'abonne ici pour ignorer le micro pendant nos propres sons */
let onOwnSound: ((sec: number) => void) | null = null;
export function setOwnSoundListener(fn: ((sec: number) => void) | null) {
  onOwnSound = fn;
}

async function applyMode() {
  // Joue même si le téléphone est en mode silencieux (c'est le but !)
  // allowsRecording garde le micro ouvert pour le détecteur, le son reste sur le haut-parleur
  await setAudioModeAsync({
    playsInSilentMode: true,
    allowsRecording: micOn,
    shouldRouteThroughEarpiece: false,
  });
  modeApplied = true;
}

/** Ouvre ou ferme l'accès micro (détecteur de prouts) */
export async function setMicMode(on: boolean) {
  micOn = on;
  await applyMode().catch(() => {});
}

export async function playFart(kind: FartKind) {
  try {
    if (!modeApplied) await applyMode();
    onOwnSound?.(3);
    player?.remove();
    player = createAudioPlayer(SOURCES[kind]);
    player.play();
  } catch {
    // Le son est un bonus : on ne bloque jamais l'appli pour ça
  }
}

/** Durée totale « sirène + voix » pendant laquelle le détecteur se bouche les oreilles */
export const ALARM_TOTAL_SEC = ALARM_SEC + 3.5;

/**
 * Sirène de 2 secondes, volume maximum de l'appli,
 * puis (option) la voix du téléphone : « Mais qui c'est qui a pété ?! » sur un ton comique.
 */
export async function playAlarm(withVoice = true) {
  try {
    if (!modeApplied) await applyMode();
    onOwnSound?.(withVoice ? ALARM_TOTAL_SEC : ALARM_SEC + 1.5);
    alarmPlayer?.remove();
    alarmPlayer = createAudioPlayer(ALARM);
    alarmPlayer.volume = 1;
    alarmPlayer.play();
    if (withVoice) setTimeout(sayWhoFarted, ALARM_SEC * 1000 + 150);
  } catch {}
}

/** Voix aiguë et un peu traînante = effet « dessin animé » */
export function sayWhoFarted() {
  try {
    onOwnSound?.(3.5); // le détecteur ne doit pas se déclencher sur sa propre voix
    Speech.stop();
    Speech.speak('Mais qui c\'est qui a pété ?!', {
      language: 'fr-FR',
      pitch: 1.6,
      rate: 0.9,
      volume: 1,
    });
  } catch {}
}
