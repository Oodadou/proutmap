/**
 * Détecteur de « prout suspect » à partir du son brut du micro.
 *
 * Principe (simple et léger, tout se passe sur le téléphone, rien n'est enregistré) :
 *  1. le son est découpé en tranches de 50 ms ;
 *  2. on suit en continu le niveau du bruit de fond de la pièce ;
 *  3. un « événement » commence quand le son dépasse nettement ce bruit de fond ;
 *  4. à la fin de l'événement, on le garde s'il est COURT (0,15 à 2,5 s)
 *     et, si le filtre est activé, s'il est plutôt GRAVE (les claquements, la vaisselle
 *     et les sifflements sont aigus).
 *
 * Ce n'est pas de la reconnaissance par IA : une toux grave ou une chaise qui racle
 * peuvent déclencher. D'où le réglage de sensibilité et le bouton « Fausse alerte ».
 */

export type Sensitivity = 'faible' | 'normale' | 'forte';

/** Dépassement du bruit de fond (en dB) nécessaire pour déclencher */
const MARGIN_DB: Record<Sensitivity, number> = { faible: 22, normale: 16, forte: 10 };

const FRAME_SEC = 0.05; // 50 ms
const MIN_EVENT_SEC = 0.15;
const MAX_EVENT_SEC = 2.5;
const ABS_FLOOR_DB = -55; // en dessous, c'est trop faible pour être entendu
const MIN_NOISE_DB = -70;
const LOWPASS_HZ = 500; // limite « graves »
const MIN_LOW_RATIO = 0.3; // part minimale d'énergie dans les graves
const WARMUP_SEC = 1; // temps pour mesurer le bruit de fond au démarrage

export type DetectorOptions = {
  sensitivity: Sensitivity;
  /** Ignorer les bruits aigus (claquements, vaisselle…) */
  bassFilter: boolean;
};

export type DetectorEvent = {
  durationSec: number;
  peakDb: number;
  lowRatio: number;
};

export class FartDetector {
  opts: DetectorOptions;
  /** Niveau actuel (dBFS, de -100 à 0), pour l'indicateur à l'écran */
  levelDb = -100;
  noiseDb = -60;

  private sampleRate = 0;
  private frameLen = 0;
  private buf: Float32Array = new Float32Array(0);
  private bufPos = 0;
  private lp = 0; // état du filtre passe-bas
  private lpAlpha = 0;
  private elapsed = 0;

  // Événement en cours
  private inEvent = false;
  private evFrames = 0;
  private evQuiet = 0;
  private evPeak = -100;
  private evLow = 0;
  private evTotal = 0;

  private mutedUntil = 0;
  private onEvent: (e: DetectorEvent) => void;

  constructor(opts: DetectorOptions, onEvent: (e: DetectorEvent) => void) {
    this.opts = opts;
    this.onEvent = onEvent;
  }

  /** Repart de zéro (nouveau réglage du bruit de fond) au prochain paquet de son */
  reset() {
    this.sampleRate = 0;
  }

  /** Ignore le micro pendant `sec` secondes (pendant nos propres sons, l'alarme…) */
  mute(sec: number) {
    this.mutedUntil = Math.max(this.mutedUntil, this.elapsed + sec);
    this.resetEvent();
  }

  /** À appeler avec chaque paquet d'échantillons mono (valeurs entre -1 et 1) */
  push(samples: Float32Array, sampleRate: number) {
    if (sampleRate !== this.sampleRate) this.setup(sampleRate);
    for (let i = 0; i < samples.length; i++) {
      this.buf[this.bufPos++] = samples[i];
      if (this.bufPos === this.frameLen) {
        this.frame(this.buf);
        this.bufPos = 0;
      }
    }
  }

  private setup(sr: number) {
    this.sampleRate = sr;
    this.frameLen = Math.max(1, Math.round(sr * FRAME_SEC));
    this.buf = new Float32Array(this.frameLen);
    this.bufPos = 0;
    this.lpAlpha = 1 - Math.exp((-2 * Math.PI * LOWPASS_HZ) / sr);
    this.elapsed = 0;
    this.noiseDb = -60;
    this.resetEvent();
  }

  private resetEvent() {
    this.inEvent = false;
    this.evFrames = this.evQuiet = this.evLow = this.evTotal = 0;
    this.evPeak = -100;
  }

  private frame(x: Float32Array) {
    let sum = 0;
    let sumLow = 0;
    let lp = this.lp;
    const a = this.lpAlpha;
    for (let i = 0; i < x.length; i++) {
      const s = x[i];
      lp += a * (s - lp);
      sum += s * s;
      sumLow += lp * lp;
    }
    this.lp = lp;
    const db = 10 * Math.log10(sum / x.length + 1e-12);
    this.levelDb = Math.max(-100, db);
    this.elapsed += FRAME_SEC;

    // Pendant la mise en route ou une coupure : on apprend juste le bruit de fond
    if (this.elapsed < WARMUP_SEC) {
      this.noiseDb = this.elapsed <= FRAME_SEC ? db : this.noiseDb + 0.2 * (db - this.noiseDb);
      this.noiseDb = Math.max(MIN_NOISE_DB, this.noiseDb);
      return;
    }
    if (this.elapsed < this.mutedUntil) return;

    const threshold = Math.max(ABS_FLOOR_DB, this.noiseDb + MARGIN_DB[this.opts.sensitivity]);
    const loud = db > threshold;

    if (!this.inEvent) {
      if (loud) {
        this.inEvent = true;
        this.evFrames = 1;
        this.evQuiet = 0;
        this.evPeak = db;
        this.evLow = sumLow;
        this.evTotal = sum;
      } else {
        // Le bruit de fond suit lentement la pièce (monte lentement, redescend plus vite)
        const k = db > this.noiseDb ? 0.01 : 0.05;
        this.noiseDb = Math.max(MIN_NOISE_DB, this.noiseDb + k * (db - this.noiseDb));
      }
      return;
    }

    // Événement en cours
    this.evFrames++;
    this.evLow += sumLow;
    this.evTotal += sum;
    if (loud) {
      this.evQuiet = 0;
      this.evPeak = Math.max(this.evPeak, db);
    } else {
      this.evQuiet++;
    }

    const durationSec = (this.evFrames - this.evQuiet) * FRAME_SEC;
    if (durationSec > MAX_EVENT_SEC + 0.5) {
      // Bruit long (musique, conversation, aspirateur…) : on l'ignore et on s'y adapte
      // (le seuil passe au-dessus du bruit actuel ; il redescendra quand le calme reviendra)
      this.noiseDb = Math.max(this.noiseDb, this.evPeak - MARGIN_DB[this.opts.sensitivity] + 3);
      this.resetEvent();
      return;
    }
    // Fin de l'événement après 150 ms de calme
    if (this.evQuiet >= 3) {
      const lowRatio = this.evTotal > 0 ? this.evLow / this.evTotal : 0;
      const ok =
        durationSec >= MIN_EVENT_SEC &&
        durationSec <= MAX_EVENT_SEC &&
        (!this.opts.bassFilter || lowRatio >= MIN_LOW_RATIO);
      const ev = { durationSec, peakDb: this.evPeak, lowRatio };
      this.resetEvent();
      if (ok) this.onEvent(ev);
    }
  }
}

/** Convertit un paquet PCM (float32 ou int16, éventuellement stéréo) en mono float */
export function toMonoFloat(data: ArrayBuffer, channels: number, encoding: 'float32' | 'int16') {
  const src = encoding === 'int16' ? new Int16Array(data) : new Float32Array(data);
  const scale = encoding === 'int16' ? 1 / 32768 : 1;
  const n = Math.floor(src.length / channels);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    let s = 0;
    for (let c = 0; c < channels; c++) s += src[i * channels + c];
    out[i] = (s / channels) * scale;
  }
  return out;
}
