/**
 * Adresse et clé du serveur Supabase.
 * La clé « publishable » est faite pour être dans l'appli : elle est publique,
 * la sécurité vient des règles de la base (Row Level Security).
 * ⚠️ Ne JAMAIS mettre ici la clé secrète (sb_secret_… / service_role).
 */
export const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL || 'https://aeitlkmewlefmvhezetx.supabase.co';
export const SUPABASE_KEY =
  process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || 'sb_publishable_riSqi7S5ezUCkTcOjtSTHg_Z__x4gFO';

/**
 * Mode démo (sans serveur) par défaut. La vraie version est activée uniquement par
 * EXPO_PUBLIC_REAL=1 (profils Expo « preview » et « production » dans eas.json).
 * Ainsi l'APK de démo fabriqué par GitHub reste toujours une démo.
 */
export const IS_DEMO = process.env.EXPO_PUBLIC_DEMO === '1' || process.env.EXPO_PUBLIC_REAL !== '1';

/**
 * Connexion Google : identifiant « Web » du projet Google Cloud « Prout Map »
 * (public, c'est lui que Supabase vérifie). L'identifiant iOS viendra avec la version iPhone.
 */
export const GOOGLE_WEB_CLIENT_ID =
  process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID ||
  '278174679289-n3e67kqld94ivurj6iutl8hhi8qcqchh.apps.googleusercontent.com';
export const GOOGLE_IOS_CLIENT_ID = process.env.EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID || undefined;
