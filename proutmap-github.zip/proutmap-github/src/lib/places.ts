/**
 * Mes lieux (Maison, Boulot, Chez un pote…) : enregistrés UNIQUEMENT sur le téléphone.
 * Un prout fait à moins de PLACE_RADIUS_M d'un lieu y est rattaché automatiquement
 * (calculé à l'affichage, donc ça marche aussi pour les anciens prouts).
 */
import AsyncStorage from '@react-native-async-storage/async-storage';

export type PlaceKind = 'maison' | 'boulot' | 'pote' | 'autre';
export type Place = { id: string; name: string; kind: PlaceKind; lat: number; lng: number };

export const PLACE_KINDS: { value: PlaceKind; label: string; emoji: string }[] = [
  { value: 'maison', label: 'Maison', emoji: '🏠' },
  { value: 'boulot', label: 'Boulot', emoji: '💼' },
  { value: 'pote', label: 'Chez un pote', emoji: '🍻' },
  { value: 'autre', label: 'Autre', emoji: '📍' },
];
export const placeEmoji = (k: PlaceKind) => PLACE_KINDS.find((x) => x.value === k)?.emoji ?? '📍';

export const PLACE_RADIUS_M = 100;
const KEY = 'proutmap-places-v1';

/** Distance approximative en mètres (suffisant à l'échelle d'une pièce ou d'une rue) */
export function distanceM(lat1: number, lng1: number, lat2: number, lng2: number) {
  const dy = (lat2 - lat1) * 111_320;
  const dx = (lng2 - lng1) * 111_320 * Math.cos((lat1 * Math.PI) / 180);
  return Math.sqrt(dx * dx + dy * dy);
}

export async function listPlaces(): Promise<Place[]> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Place[]) : [];
  } catch {
    return [];
  }
}

async function savePlaces(list: Place[]) {
  await AsyncStorage.setItem(KEY, JSON.stringify(list));
}

export async function addPlace(p: Omit<Place, 'id'>) {
  const list = await listPlaces();
  list.push({ ...p, name: p.name.trim(), id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}` });
  await savePlaces(list);
}

export async function deletePlace(id: string) {
  await savePlaces((await listPlaces()).filter((p) => p.id !== id));
}

/** Le lieu enregistré le plus proche (dans le rayon), ou null */
export function placeFor(lat: number, lng: number, places: Place[]): Place | null {
  let best: Place | null = null;
  let bestD = PLACE_RADIUS_M;
  for (const p of places) {
    const d = distanceM(lat, lng, p.lat, p.lng);
    if (d <= bestD) {
      best = p;
      bestD = d;
    }
  }
  return best;
}

export const placeLabel = (p: Place) => `${placeEmoji(p.kind)} ${p.name}`;

/** Effacé avec le compte (ou la remise à zéro de la démo) */
export async function clearPlaces() {
  await AsyncStorage.removeItem(KEY).catch(() => {});
}

/** Restauration d'une sauvegarde : ajoute les lieux qui ne sont pas déjà là. Renvoie le nombre ajouté. */
export async function restorePlaces(list: Omit<Place, 'id'>[]) {
  const cur = await listPlaces();
  let added = 0;
  for (const p of list ?? []) {
    if (typeof p?.lat !== 'number' || typeof p?.lng !== 'number' || !p.name) continue;
    const dup = cur.some((c) => c.name === p.name && distanceM(c.lat, c.lng, p.lat, p.lng) < 10);
    if (dup) continue;
    cur.push({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      name: String(p.name).slice(0, 30),
      kind: PLACE_KINDS.some((k) => k.value === p.kind) ? p.kind : 'autre',
      lat: p.lat,
      lng: p.lng,
    });
    added++;
  }
  await savePlaces(cur);
  return added;
}
