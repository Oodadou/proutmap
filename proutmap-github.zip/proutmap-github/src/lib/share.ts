/**
 * Partage des exploits par WhatsApp, SMS, Messenger… via le menu de partage du téléphone.
 * Aucun serveur : c'est le téléphone qui envoie le message, donc 0 € de frais.
 */
import { Share } from 'react-native';

import { kindInfo, type Fart } from './types';

// Lien ajouté en bas des messages : la page d'accueil (dossier site/ du projet).
// WhatsApp, Messenger… affichent dessous une carte d'aperçu avec l'icône et un bouton.
// Une fois l'appli publiée, il suffit de mettre les liens des stores sur cette page.
export const SHARE_URL = process.env.EXPO_PUBLIC_SHARE_URL || 'https://oodadou.github.io/proutmap/';

const footer = `\n\n👉 ${SHARE_URL}`;

/** Ajoute le lien de l'appli à n'importe quel message */
export const withLink = (message: string) => message + footer;

async function share(message: string) {
  try {
    await Share.share({ message });
  } catch {
    // L'utilisateur a fermé le menu : rien à faire
  }
}

export function shareFart(f: Fart) {
  const k = kindInfo(f.kind);
  const lines = [
    `${k.emoji} Prout ${k.label.toLowerCase()} déclaré !`,
    k.badge ? `😬 ${k.badge}` : null,
    `💪 ${f.power}/5 · 🤢 ${f.smell}/5 · 🥷 ${f.discretion}/5`,
    f.victim_name ? `😈 Victime : ${f.victim_name} xD` : null,
    f.note ? `« ${f.note} »` : null,
  ];
  return share(lines.filter(Boolean).join('\n') + footer);
}

export function shareStats(s: {
  total: number;
  week: number;
  record: number;
  streak: number;
  victims: number;
  received: number;
  foireux: number;
}) {
  const lines = [
    '🏆 Mes exploits sur Prout Map',
    `💨 ${s.total} prouts au total, dont ${s.week} cette semaine`,
    `🏅 Record : ${s.record} en un jour · 🔥 ${s.streak} jour${s.streak > 1 ? 's' : ''} d'affilée`,
    `😈 ${s.victims} lâché${s.victims > 1 ? 's' : ''} sur quelqu'un · 😱 ${s.received} reçu${s.received > 1 ? 's' : ''}`,
    s.foireux ? `😬 ${s.foireux} excès de confiance` : null,
    'Viens te mesurer à moi 😏',
  ];
  return share(lines.filter(Boolean).join('\n') + footer);
}

export function shareDetector(c: { detected: number; declared: number; alarms: number }) {
  return share(
    `🎙️ Le détecteur de prouts a frappé !\n💨 ${c.detected} suspect${c.detected > 1 ? 's' : ''} · ✅ ${c.declared} assumé${c.declared > 1 ? 's' : ''} · 🚨 ${c.alarms} coupable${c.alarms > 1 ? 's' : ''} démasqué${c.alarms > 1 ? 's' : ''}` +
      footer,
  );
}
