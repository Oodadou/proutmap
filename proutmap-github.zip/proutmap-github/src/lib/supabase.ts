import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import { AppState } from 'react-native';

import { IS_DEMO, SUPABASE_KEY, SUPABASE_URL } from './config';

// En mode démo, le serveur n'est jamais contacté
const url = IS_DEMO ? 'https://demo.invalid' : SUPABASE_URL;
const anonKey = IS_DEMO ? 'demo' : SUPABASE_KEY;

export const supabase = createClient(url, anonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

// Rafraîchit le jeton seulement quand l'appli est au premier plan
AppState.addEventListener('change', (state) => {
  if (state === 'active') supabase.auth.startAutoRefresh();
  else supabase.auth.stopAutoRefresh();
});
