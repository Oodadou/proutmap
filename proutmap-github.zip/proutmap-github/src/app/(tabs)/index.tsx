import * as Location from 'expo-location';
import { router, useFocusEffect, useLocalSearchParams } from 'expo-router';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';

import { FartMap, type FartMapHandle } from '@/components/fart-map';
import { Chip } from '@/components/ui';
import { deleteFart, reportFart, visibleFarts } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { DEMO, demoSeed } from '@/lib/demo';
import { listPlaces, type Place } from '@/lib/places';
import { shareFart } from '@/lib/share';
import { colors } from '@/lib/theme';
import type { Fart } from '@/lib/types';

type Filter = 'tout' | 'moi' | 'amis' | 'recus';

export default function MapScreen() {
  const { session } = useAuth();
  const me = session!.user.id;
  const [farts, setFarts] = useState<Fart[]>([]);
  const [filter, setFilter] = useState<Filter>('tout');
  const [pos, setPos] = useState<{ lat: number; lng: number } | null>(null);
  const [places, setPlaces] = useState<Place[]>([]);
  const [placing, setPlacing] = useState(false);
  const [mapReady, setMapReady] = useState(false);
  const mapRef = useRef<FartMapHandle>(null);
  const { focus } = useLocalSearchParams<{ focus?: string }>();

  const reload = useCallback(() => {
    visibleFarts().then(setFarts).catch(() => {});
  }, []);

  useFocusEffect(
    useCallback(() => {
      reload();
      listPlaces().then(setPlaces);
    }, [reload]),
  );

  // « Voir sur la carte » depuis l'historique
  useEffect(() => {
    if (!focus || !mapReady || farts.length === 0) return;
    setFilter('tout');
    const t = setTimeout(() => {
      mapRef.current?.focusFart(Number(focus));
      router.setParams({ focus: undefined });
    }, 300);
    return () => clearTimeout(t);
  }, [focus, mapReady, farts]);

  // Bouton « ma position » : relit le GPS puis recentre
  async function recenter() {
    try {
      const p = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const here = { lat: p.coords.latitude, lng: p.coords.longitude };
      setPos(here);
      mapRef.current?.recenter(here.lat, here.lng);
    } catch {
      if (pos) mapRef.current?.recenter(pos.lat, pos.lng);
      else Alert.alert('Position introuvable', 'Autorise la localisation pour te retrouver sur la carte.');
    }
  }

  async function confirmPlace() {
    const c = await mapRef.current?.getCenter();
    setPlacing(false);
    if (c) router.push({ pathname: '/place-new', params: { lat: String(c.lat), lng: String(c.lng) } });
  }

  // Position de l'utilisateur (et, en démo, les faux amis placés autour)
  useEffect(() => {
    (async () => {
      const { granted } = await Location.requestForegroundPermissionsAsync();
      if (!granted) return;
      const p =
        (await Location.getLastKnownPositionAsync()) ??
        (await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }));
      if (!p) return;
      setPos({ lat: p.coords.latitude, lng: p.coords.longitude });
      if (DEMO) {
        await demoSeed(p.coords.latitude, p.coords.longitude);
        reload();
      }
    })().catch(() => {});
  }, [reload]);

  // En démo, on rafraîchit régulièrement pour voir arriver les vengeances
  useEffect(() => {
    if (!DEMO) return;
    const t = setInterval(reload, 5000);
    return () => clearInterval(t);
  }, [reload]);

  const shown = useMemo(
    () =>
      farts.filter((f) => {
        if (filter === 'moi') return f.user_id === me;
        if (filter === 'amis') return f.user_id !== me && f.victim_id !== me;
        if (filter === 'recus') return f.victim_id === me;
        return true;
      }),
    [farts, filter, me],
  );

  function onFartPress(f: Fart) {
    if (f.user_id === me) {
      Alert.alert('Ton prout', undefined, [
        { text: 'Annuler', style: 'cancel' },
        { text: '📤 Partager', onPress: () => shareFart(f) },
        {
          text: 'Supprimer',
          style: 'destructive',
          onPress: async () => {
            await deleteFart(f.id);
            setFarts((all) => all.filter((x) => x.id !== f.id));
          },
        },
      ]);
    } else {
      Alert.alert('Signaler ce contenu ?', 'Notre équipe vérifiera la note associée.', [
        { text: 'Annuler', style: 'cancel' },
        { text: 'Signaler', style: 'destructive', onPress: () => reportFart(f, 'Signalé depuis la carte') },
      ]);
    }
  }

  return (
    <View style={{ flex: 1 }}>
      <FartMap
        ref={mapRef}
        farts={shown}
        places={places}
        me={me}
        myPosition={pos}
        onFartPress={onFartPress}
        onReady={() => setMapReady(true)}
      />

      <View style={styles.filters} pointerEvents="box-none">
        <Chip label="Tout" selected={filter === 'tout'} onPress={() => setFilter('tout')} />
        <Chip label="Moi" selected={filter === 'moi'} onPress={() => setFilter('moi')} />
        <Chip label="Amis" selected={filter === 'amis'} onPress={() => setFilter('amis')} />
        <Chip label="Reçus 😱" selected={filter === 'recus'} onPress={() => setFilter('recus')} />
      </View>

      {DEMO && (
        <View style={styles.demo} pointerEvents="none">
          <Text style={styles.demoText}>MODE DÉMO</Text>
        </View>
      )}

      {placing ? (
        <>
          <View style={styles.crosshair} pointerEvents="none">
            <Text style={styles.crosshairText}>✛</Text>
          </View>
          <View style={styles.placeBar}>
            <Text style={styles.placeHint}>Déplace la carte pour viser le lieu</Text>
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <Pressable style={[styles.barBtn, { backgroundColor: colors.card }]} onPress={() => setPlacing(false)}>
                <Text style={[styles.barBtnText, { color: colors.text }]}>Annuler</Text>
              </Pressable>
              <Pressable style={[styles.barBtn, { backgroundColor: colors.primary }]} onPress={confirmPlace}>
                <Text style={styles.barBtnText}>📌 Placer ici</Text>
              </Pressable>
            </View>
          </View>
        </>
      ) : (
        <>
          <View style={styles.sideButtons}>
            <Pressable style={styles.round} onPress={() => setPlacing(true)} accessibilityLabel="Ajouter un lieu">
              <Text style={styles.roundText}>📌</Text>
            </Pressable>
            <Pressable style={styles.round} onPress={recenter} accessibilityLabel="Ma position">
              <Text style={[styles.roundText, { color: '#2a7ef4', fontSize: 26, fontWeight: '900' }]}>◎</Text>
            </Pressable>
          </View>
          <Pressable style={styles.fab} onPress={() => router.push('/new-fart')}>
            <Text style={styles.fabText}>💨 Prouter ici</Text>
          </Pressable>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  filters: {
    position: 'absolute',
    top: 12,
    left: 12,
    right: 12,
    flexDirection: 'row',
    gap: 8,
    flexWrap: 'wrap',
  },
  demo: {
    position: 'absolute',
    top: 60,
    right: 12,
    backgroundColor: colors.accent,
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  demoText: { color: '#fff', fontWeight: '900', fontSize: 11 },
  fab: {
    position: 'absolute',
    bottom: 24,
    alignSelf: 'center',
    backgroundColor: colors.primary,
    paddingVertical: 16,
    paddingHorizontal: 28,
    borderRadius: 999,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 6,
  },
  fabText: { color: '#fff', fontSize: 18, fontWeight: '900' },
  sideButtons: { position: 'absolute', right: 14, bottom: 100, gap: 12 },
  round: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: colors.card,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
    elevation: 5,
  },
  roundText: { fontSize: 22 },
  crosshair: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' },
  crosshairText: { fontSize: 44, color: colors.danger, fontWeight: '300' },
  placeBar: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 24,
    backgroundColor: colors.card,
    borderRadius: 20,
    padding: 14,
    gap: 10,
    elevation: 6,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 8,
  },
  placeHint: { color: colors.muted, textAlign: 'center' },
  barBtn: { flex: 1, borderRadius: 999, paddingVertical: 12, alignItems: 'center', borderWidth: 1, borderColor: colors.border },
  barBtnText: { color: '#fff', fontWeight: '800', fontSize: 16 },
});
