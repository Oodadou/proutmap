import { GoogleSignin } from '@react-native-google-signin/google-signin';
import { useFocusEffect } from 'expo-router';
import * as WebBrowser from 'expo-web-browser';
import { useCallback, useState } from 'react';
import { Alert, Pressable, ScrollView, Text, TextInput, View } from 'react-native';

import { Body, Button, Card, Label, styles } from '@/components/ui';
import { deleteAccount, myProfile, updateName } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { DEMO } from '@/lib/demo';
import { clearPlaces, deletePlace, listPlaces, placeLabel, type Place } from '@/lib/places';
import { colors } from '@/lib/theme';

// À remplacer par l'adresse de ta page de confidentialité (obligatoire sur les stores)
const PRIVACY_URL = process.env.EXPO_PUBLIC_PRIVACY_URL ?? 'https://example.com/confidentialite';

export default function Profile() {
  const { session, signOut } = useAuth();
  const me = session!.user.id;
  const [name, setName] = useState('');
  const [saved, setSaved] = useState(false);
  const [places, setPlaces] = useState<Place[]>([]);

  useFocusEffect(
    useCallback(() => {
      myProfile().then((p) => p && setName(p.display_name));
      listPlaces().then(setPlaces);
    }, []),
  );

  function onDeletePlace(p: Place) {
    Alert.alert(`Supprimer « ${p.name} » ?`, undefined, [
      { text: 'Annuler', style: 'cancel' },
      {
        text: 'Supprimer',
        style: 'destructive',
        onPress: async () => {
          await deletePlace(p.id);
          setPlaces(await listPlaces());
        },
      },
    ]);
  }

  async function onSave() {
    if (!name.trim()) return;
    await updateName(me, name);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  }

  async function onSignOut() {
    if (!DEMO) await GoogleSignin.signOut().catch(() => {});
    await signOut();
  }

  function onDelete() {
    Alert.alert(
      DEMO ? 'Remettre la démo à zéro ?' : 'Supprimer mon compte ?',
      'Tous tes prouts, amis et ligues seront effacés définitivement.',
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Supprimer',
          style: 'destructive',
          onPress: async () => {
            try {
              if (!DEMO) await GoogleSignin.signOut().catch(() => {});
              await deleteAccount();
              await clearPlaces();
              await signOut();
            } catch (e: any) {
              Alert.alert('Erreur', e?.message ?? String(e));
            }
          },
        },
      ],
    );
  }

  return (
    <ScrollView contentContainerStyle={{ padding: 16, gap: 16 }}>
      <Card>
        <Label>Mon pseudo</Label>
        <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
          <TextInput
            style={[styles.input, { flex: 1 }]}
            value={name}
            onChangeText={setName}
            maxLength={30}
            placeholder="Ton pseudo"
            placeholderTextColor={colors.muted}
          />
          <Button title={saved ? '✓' : 'OK'} onPress={onSave} />
        </View>
        <Body style={{ color: colors.muted, marginTop: 8, fontSize: 13 }}>
          C'est le nom que voient tes amis et les membres de tes ligues.
        </Body>
      </Card>

      <Card>
        <Label>Mes lieux</Label>
        {places.length === 0 ? (
          <Body style={{ color: colors.muted, marginTop: 8 }}>
            Aucun lieu. Sur la carte, touche 📌 puis vise ta maison, ton boulot, chez un pote…
          </Body>
        ) : (
          places.map((p) => (
            <View
              key={p.id}
              style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 10 }}>
              <Body>{placeLabel(p)}</Body>
              <Pressable onPress={() => onDeletePlace(p)} hitSlop={8}>
                <Text style={{ color: colors.danger, fontWeight: '700' }}>Supprimer</Text>
              </Pressable>
            </View>
          ))
        )}
        <Body style={{ color: colors.muted, marginTop: 10, fontSize: 13 }}>
          Tes lieux restent sur ton téléphone : tes amis ne les voient pas.
        </Body>
      </Card>

      <Card style={{ gap: 10 }}>
        <Button
          title="Politique de confidentialité"
          variant="secondary"
          onPress={() => WebBrowser.openBrowserAsync(PRIVACY_URL)}
        />
        <Button title="Se déconnecter" variant="secondary" onPress={onSignOut} />
        <Button title={DEMO ? 'Remettre la démo à zéro' : 'Supprimer mon compte'} variant="danger" onPress={onDelete} />
      </Card>
    </ScrollView>
  );
}
