/**
 * 🎵 Onglet « Bande son » : tous les sons de l'appli, personnalisables un par un.
 */
import { router, useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';

import { Body, Card, Label } from '@/components/ui';
import { getSoundPrefs, isCustom, playSlot, slotLabel, SLOTS, type SlotInfo, type SoundPrefs } from '@/lib/sounds';
import { colors } from '@/lib/theme';
import { KINDS } from '@/lib/types';

const GROUPS: { title: string; slots: SlotInfo['slot'][] }[] = [
  { title: '💨 Mes prouts', slots: KINDS.map((k) => k.value) },
  { title: '😈 Phrases cultes', slots: ['oups'] },
  { title: '🎙️ Détecteur', slots: ['alarme', 'assume'] },
];

export default function SoundsTab() {
  const [prefs, setPrefs] = useState<SoundPrefs | null>(null);

  useFocusEffect(
    useCallback(() => {
      getSoundPrefs().then((p) => setPrefs(JSON.parse(JSON.stringify(p))));
    }, []),
  );

  const libraryCount = prefs?.library.length ?? 0;

  return (
    <ScrollView contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 48 }}>
      <Body style={{ color: colors.muted }}>
        Remplace n'importe quel son par ta voix, un vrai prout de l'enfer ou un son importé… et envoie tes meilleurs
        sons à tes potes.
      </Body>

      <Pressable onPress={() => router.push('/library')}>
        <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 12, borderColor: colors.primary, borderWidth: 2 }}>
          <Text style={{ fontSize: 34 }}>📚</Text>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 18, fontWeight: '900', color: colors.text }}>Ma sonothèque</Text>
            <Text style={{ color: colors.muted }}>
              {libraryCount ? `${libraryCount} son${libraryCount > 1 ? 's' : ''} · enregistrer, importer, attribuer` : 'Enregistre ou importe tes sons, puis attribue-les'}
            </Text>
          </View>
          <Text style={{ color: colors.primaryDark, fontWeight: '800' }}>Ouvrir ›</Text>
        </Card>
      </Pressable>

      {GROUPS.map((g) => (
        <Card key={g.title} style={{ gap: 4 }}>
          <Label>{g.title}</Label>
          {g.slots.map((slot) => {
            const info = SLOTS.find((s) => s.slot === slot)!;
            const custom = !!prefs && isCustom(slot, prefs);
            return (
              <View
                key={slot}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 10,
                  paddingVertical: 10,
                  borderTopWidth: 1,
                  borderTopColor: colors.border,
                }}>
                <Pressable
                  onPress={() => playSlot(slot)}
                  hitSlop={8}
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 22,
                    backgroundColor: custom ? colors.accent : colors.bg,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                  accessibilityLabel="Écouter">
                  <Text style={{ fontSize: 18 }}>▶️</Text>
                </Pressable>
                <Pressable style={{ flex: 1 }} onPress={() => router.push({ pathname: '/sound/[slot]', params: { slot } })}>
                  <Text style={{ fontWeight: '800', color: colors.text, fontSize: 15 }}>
                    {info.emoji} {info.title}
                  </Text>
                  <Text style={{ color: custom ? colors.primaryDark : colors.muted, fontSize: 13 }} numberOfLines={1}>
                    {prefs ? slotLabel(slot, prefs) : '…'}
                  </Text>
                </Pressable>
                <Pressable onPress={() => router.push({ pathname: '/sound/[slot]', params: { slot } })} hitSlop={8}>
                  <Text style={{ color: colors.primaryDark, fontWeight: '800' }}>Modifier ›</Text>
                </Pressable>
              </View>
            );
          })}
        </Card>
      ))}

      <Card>
        <Label>Bientôt</Label>
        <Body style={{ marginTop: 6 }}>
          🏆 Les sons de la ligue : publier tes sons dans tes ligues, piocher ceux de tes potes en un clic et élire le
          son de la semaine (avec la version serveur).
        </Body>
      </Card>
    </ScrollView>
  );
}
