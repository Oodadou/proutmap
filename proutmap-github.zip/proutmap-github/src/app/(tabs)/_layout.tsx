import { router } from 'expo-router';
import Tabs from 'expo-router/js-tabs';
import { Pressable, Text } from 'react-native';

import { colors } from '@/lib/theme';

const icon = (emoji: string) =>
  function TabIcon({ focused }: { focused: boolean }) {
    return <Text style={{ fontSize: 22, opacity: focused ? 1 : 0.5 }}>{emoji}</Text>;
  };

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerStyle: { backgroundColor: colors.bg },
        headerTintColor: colors.text,
        headerTitleStyle: { fontWeight: '800' },
        tabBarActiveTintColor: colors.primaryDark,
        tabBarInactiveTintColor: colors.muted,
        tabBarStyle: { backgroundColor: colors.card },
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Carte',
          tabBarIcon: icon('🗺️'),
          headerRight: () => (
            <Pressable
              onPress={() => router.push('/detector')}
              hitSlop={8}
              style={{ marginRight: 16, flexDirection: 'row', alignItems: 'center', gap: 4 }}>
              <Text style={{ fontSize: 20 }}>🎙️</Text>
              <Text style={{ color: colors.primaryDark, fontWeight: '800' }}>Détecteur</Text>
            </Pressable>
          ),
        }}
      />
      <Tabs.Screen name="stats" options={{ title: 'Stats', tabBarIcon: icon('📊') }} />
      <Tabs.Screen name="sounds" options={{ title: 'Bande son', tabBarIcon: icon('🎵') }} />
      <Tabs.Screen name="friends" options={{ title: 'Amis', tabBarIcon: icon('👯') }} />
      <Tabs.Screen name="leagues" options={{ title: 'Ligues', tabBarIcon: icon('🏆') }} />
      <Tabs.Screen name="profile" options={{ title: 'Moi', tabBarIcon: icon('🙂') }} />
    </Tabs>
  );
}
