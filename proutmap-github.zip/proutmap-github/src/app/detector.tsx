/**
 * 🎙️ Détecteur de prouts
 *
 * Le micro écoute la pièce. Bruit court et fort → compte à rebours (10 ou 15 s).
 * Si personne à proximité (≈ 50 m, ami ou pas) ne déclare de prout dans l'appli
 * pendant ce temps → sirène de 2 secondes.
 *
 * Confidentialité : le son est analysé en direct sur le téléphone, jamais enregistré
 * ni envoyé. Le micro ne fonctionne que tant que cet écran est ouvert.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { requestRecordingPermissionsAsync, useAudioStream, type AudioStreamBuffer } from 'expo-audio';
import * as Haptics from 'expo-haptics';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';
import * as Location from 'expo-location';
import { router } from 'expo-router';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Alert, AppState, ScrollView, Switch, Text, Vibration, View } from 'react-native';

import { Body, Button, Card, Chip, Label } from '@/components/ui';
import { addFart, declaredNearby } from '@/lib/api';
import { FartDetector, toMonoFloat, type Sensitivity } from '@/lib/fart-detector';
import { shareDetector } from '@/lib/share';
import { ALARM_TOTAL_SEC, playAlarm, playFart, sayWhoFarted, setMicMode, setOwnSoundListener } from '@/lib/sounds';
import { colors } from '@/lib/theme';

type Phase = 'off' | 'listening' | 'countdown' | 'declared' | 'alarm';
type Settings = { sensitivity: Sensitivity; bassFilter: boolean; delay: 10 | 15; voice: boolean };

const SETTINGS_KEY = 'proutmap-detector-v1';
const DEFAULTS: Settings = { sensitivity: 'normale', bassFilter: true, delay: 15, voice: true };
const KEEP_AWAKE_TAG = 'detector';
const POLL_MS = 2000;
/** Un prout déclaré jusqu'à 30 s AVANT la détection compte aussi (le coupable a été rapide) */
const GRACE_SEC = 30;

export default function DetectorScreen() {
  const [settings, setSettings] = useState<Settings>(DEFAULTS);
  const [phase, setPhase] = useState<Phase>('off');
  const [level, setLevel] = useState(0); // 0..1 pour la jauge
  const [remaining, setRemaining] = useState(0);
  const [declaredBy, setDeclaredBy] = useState<'moi' | 'proche'>('proche');
  const [counts, setCounts] = useState({ detected: 0, declared: 0, alarms: 0 });
  const [noPosition, setNoPosition] = useState(false);

  const phaseRef = useRef<Phase>('off');
  const detectedAt = useRef(0);
  const pos = useRef<{ lat: number; lng: number } | null>(null);
  const watchSub = useRef<Location.LocationSubscription | null>(null);

  const setPhaseBoth = useCallback((p: Phase) => {
    phaseRef.current = p;
    setPhase(p);
  }, []);

  // ---- Détecteur (moteur audio) ------------------------------------------------
  const onSuspect = useCallback(() => {
    if (phaseRef.current !== 'listening') return;
    detectedAt.current = Date.now();
    setCounts((c) => ({ ...c, detected: c.detected + 1 }));
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning).catch(() => {});
    setPhaseBoth('countdown');
  }, [setPhaseBoth]);

  const onSuspectRef = useRef(onSuspect);
  onSuspectRef.current = onSuspect;
  const detector = useRef<FartDetector | null>(null);
  if (!detector.current) detector.current = new FartDetector(DEFAULTS, () => onSuspectRef.current());

  const onBuffer = useCallback((b: AudioStreamBuffer) => {
    detector.current!.push(toMonoFloat(b.data, b.channels || 1, 'float32'), b.sampleRate);
  }, []);

  const { stream } = useAudioStream({ sampleRate: 16000, channels: 1, encoding: 'float32', onBuffer });

  // Réglages enregistrés sur le téléphone
  useEffect(() => {
    AsyncStorage.getItem(SETTINGS_KEY)
      .then((raw) => raw && setSettings({ ...DEFAULTS, ...JSON.parse(raw) }))
      .catch(() => {});
  }, []);
  useEffect(() => {
    detector.current!.opts = { sensitivity: settings.sensitivity, bassFilter: settings.bassFilter };
    AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)).catch(() => {});
  }, [settings]);

  // ---- Marche / arrêt -----------------------------------------------------------
  const stopListening = useCallback(() => {
    try {
      stream.stop();
    } catch {}
    watchSub.current?.remove();
    watchSub.current = null;
    setOwnSoundListener(null);
    setMicMode(false);
    deactivateKeepAwake(KEEP_AWAKE_TAG).catch(() => {});
    setPhaseBoth('off');
    setLevel(0);
  }, [stream, setPhaseBoth]);

  const startListening = useCallback(async () => {
    const mic = await requestRecordingPermissionsAsync();
    if (!mic.granted) {
      Alert.alert(
        'Micro refusé',
        "Le détecteur a besoin du micro pour entendre les prouts. Le son est analysé sur ton téléphone et n'est jamais enregistré. Tu peux l'autoriser dans les réglages du téléphone.",
      );
      return;
    }
    try {
      const loc = await Location.requestForegroundPermissionsAsync();
      if (loc.granted) {
        const p =
          (await Location.getLastKnownPositionAsync()) ??
          (await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }));
        if (p) pos.current = { lat: p.coords.latitude, lng: p.coords.longitude };
        watchSub.current = await Location.watchPositionAsync(
          { accuracy: Location.Accuracy.Balanced, distanceInterval: 15 },
          (p) => (pos.current = { lat: p.coords.latitude, lng: p.coords.longitude }),
        );
      }
      setNoPosition(!pos.current);

      setOwnSoundListener((sec) => detector.current!.mute(sec));
      await setMicMode(true);
      detector.current!.reset();
      await stream.start();
      await activateKeepAwakeAsync(KEEP_AWAKE_TAG).catch(() => {});
      setPhaseBoth('listening');
    } catch (e: any) {
      stopListening();
      Alert.alert('Impossible de lancer le micro', e?.message ?? String(e));
    }
  }, [stream, setPhaseBoth, stopListening]);

  // Arrêt propre en quittant l'écran ou en passant l'appli en arrière-plan
  useEffect(() => {
    const sub = AppState.addEventListener('change', (st) => {
      if (st === 'background' && phaseRef.current !== 'off') stopListening();
    });
    return () => {
      sub.remove();
      stopListening();
    };
  }, [stopListening]);

  // Jauge du niveau sonore
  useEffect(() => {
    if (phase === 'off') return;
    const t = setInterval(() => {
      const d = detector.current!;
      setLevel(Math.min(1, Math.max(0, (d.levelDb + 70) / 60)));
    }, 150);
    return () => clearInterval(t);
  }, [phase]);

  // ---- Compte à rebours : quelqu'un se dénonce-t-il ? --------------------------
  const backToListening = useCallback(
    (afterMs: number) => {
      setTimeout(() => {
        if (phaseRef.current === 'declared' || phaseRef.current === 'alarm') setPhaseBoth('listening');
      }, afterMs);
    },
    [setPhaseBoth],
  );

  const resolveDeclared = useCallback(
    (by: 'moi' | 'proche') => {
      if (phaseRef.current !== 'countdown') return;
      setDeclaredBy(by);
      setCounts((c) => ({ ...c, declared: c.declared + 1 }));
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
      setPhaseBoth('declared');
      backToListening(4000);
    },
    [setPhaseBoth, backToListening],
  );

  useEffect(() => {
    if (phase !== 'countdown') return;
    let stopped = false;
    let lastPoll = 0;
    let polling = false;

    const check = async () => {
      const p = pos.current;
      if (!p || polling) return false;
      polling = true;
      try {
        const secs = (Date.now() - detectedAt.current) / 1000 + GRACE_SEC;
        return await declaredNearby(p.lat, p.lng, secs);
      } catch {
        return false; // pas de réseau : on laisse sonner
      } finally {
        polling = false;
      }
    };

    const tick = async () => {
      if (stopped || phaseRef.current !== 'countdown') return;
      const left = settings.delay - (Date.now() - detectedAt.current) / 1000;
      setRemaining(Math.max(0, Math.ceil(left)));

      if (Date.now() - lastPoll >= POLL_MS) {
        lastPoll = Date.now();
        if ((await check()) && !stopped) return resolveDeclared('proche');
      }
      if (left <= 0 && !stopped && phaseRef.current === 'countdown') {
        // Dernière vérification, puis… sirène !
        if (await check()) return resolveDeclared('proche');
        if (stopped || phaseRef.current !== 'countdown') return;
        setPhaseBoth('alarm');
        setCounts((c) => ({ ...c, alarms: c.alarms + 1 }));
        playAlarm(settings.voice);
        Vibration.vibrate([0, 400, 150, 400, 150, 400]);
        backToListening(ALARM_TOTAL_SEC * 1000);
      }
    };

    tick();
    const t = setInterval(tick, 250);
    return () => {
      stopped = true;
      clearInterval(t);
    };
  }, [phase, settings.delay, settings.voice, resolveDeclared, setPhaseBoth, backToListening]);

  // ---- Boutons pendant le compte à rebours ------------------------------------
  async function itsMe() {
    const p = pos.current;
    if (!p) {
      // Sans position, on passe par le formulaire complet
      router.push('/new-fart');
      return;
    }
    try {
      await addFart({
        lat: p.lat,
        lng: p.lng,
        kind: 'classique',
        power: 3,
        smell: 3,
        discretion: 1,
        note: 'Démasqué par le détecteur 🎙️',
        victim_id: null,
        victim_name: null,
      });
      playFart('classique');
      resolveDeclared('moi');
    } catch (e: any) {
      Alert.alert('Oups (le vrai)', e?.message ?? String(e));
    }
  }

  function falseAlarm() {
    if (phaseRef.current !== 'countdown') return;
    setPhaseBoth('listening');
  }

  // ---- Affichage ----------------------------------------------------------------
  const on = phase !== 'off';
  const panel = {
    off: { bg: colors.card, emoji: '🎙️', title: 'Détecteur éteint', sub: 'Pose le téléphone au milieu du groupe.' },
    listening: { bg: '#EEF7E6', emoji: '👂', title: 'À l’écoute…', sub: 'Le moindre prout suspect sera démasqué.' },
    countdown: {
      bg: '#FFF1D6',
      emoji: '💨',
      title: `Prout suspect ! ${remaining}`,
      sub: 'Le coupable a quelques secondes pour se déclarer dans Prout Map…',
    },
    declared: {
      bg: '#E3F4D6',
      emoji: '✅',
      title: declaredBy === 'moi' ? 'Prout déclaré, honneur sauf' : 'Un voisin s’est dénoncé',
      sub: declaredBy === 'moi' ? 'Ajouté sur ta carte.' : 'Quelqu’un à proximité a déclaré son prout. Merci pour l’honnêteté.',
    },
    alarm: { bg: '#FBD5D3', emoji: '🚨', title: 'PROUT NON DÉCLARÉ !', sub: 'Personne n’a assumé. La honte.' },
  }[phase];

  return (
    <ScrollView contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 48 }}>
      <Card style={{ backgroundColor: panel.bg, alignItems: 'center', paddingVertical: 28 }}>
        <Text style={{ fontSize: 64 }}>{panel.emoji}</Text>
        <Text style={{ fontSize: 26, fontWeight: '900', color: colors.text, textAlign: 'center', marginTop: 8 }}>
          {panel.title}
        </Text>
        <Body style={{ color: colors.muted, textAlign: 'center', marginTop: 6 }}>{panel.sub}</Body>

        {on && (
          <View style={{ alignSelf: 'stretch', height: 10, backgroundColor: colors.border, borderRadius: 5, marginTop: 18 }}>
            <View
              style={{
                height: 10,
                width: `${level * 100}%`,
                backgroundColor: phase === 'countdown' || phase === 'alarm' ? colors.danger : colors.primary,
                borderRadius: 5,
              }}
            />
          </View>
        )}

        {phase === 'countdown' && (
          <View style={{ alignSelf: 'stretch', gap: 10, marginTop: 18 }}>
            <Button title="🙋 C'est moi ! (déclarer)" onPress={itsMe} />
            <Button title="Fausse alerte" variant="secondary" onPress={falseAlarm} />
          </View>
        )}
      </Card>

      <Button
        title={on ? '⏹ Arrêter le détecteur' : '🎙️ Lancer le détecteur'}
        variant={on ? 'secondary' : 'primary'}
        onPress={on ? stopListening : startListening}
      />

      {on && noPosition && (
        <Body style={{ color: colors.danger, fontSize: 13 }}>
          Position introuvable : les prouts déclarés par les autres ne pourront pas couper l'alarme.
        </Body>
      )}

      <Card style={{ gap: 14 }}>
        <View>
          <Label>Sensibilité</Label>
          <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
            {(['faible', 'normale', 'forte'] as Sensitivity[]).map((s) => (
              <Chip
                key={s}
                label={s[0].toUpperCase() + s.slice(1)}
                selected={settings.sensitivity === s}
                onPress={() => setSettings((x) => ({ ...x, sensitivity: s }))}
              />
            ))}
          </View>
        </View>

        <View>
          <Label>Délai pour se déclarer</Label>
          <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
            {([10, 15] as const).map((d) => (
              <Chip
                key={d}
                label={`${d} secondes`}
                selected={settings.delay === d}
                onPress={() => setSettings((x) => ({ ...x, delay: d }))}
              />
            ))}
          </View>
        </View>

        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Body style={{ flex: 1, paddingRight: 8 }}>🗣️ Voix après la sirène : « Mais qui c'est qui a pété ?! »</Body>
          <Switch
            value={settings.voice}
            onValueChange={(v) => {
              setSettings((x) => ({ ...x, voice: v }));
              if (v) sayWhoFarted(); // petit aperçu
            }}
            trackColor={{ true: colors.primary }}
          />
        </View>

        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Body style={{ flex: 1, paddingRight: 8 }}>Ignorer les bruits aigus (claquements, vaisselle, sifflets)</Body>
          <Switch
            value={settings.bassFilter}
            onValueChange={(v) => setSettings((x) => ({ ...x, bassFilter: v }))}
            trackColor={{ true: colors.primary }}
          />
        </View>
      </Card>

      {counts.detected > 0 && (
        <Card>
          <Label>Cette séance</Label>
          <Text style={{ fontSize: 17, marginTop: 8, color: colors.text }}>
            💨 {counts.detected} suspect{counts.detected > 1 ? 's' : ''} · ✅ {counts.declared} déclaré
            {counts.declared > 1 ? 's' : ''} · 🚨 {counts.alarms} alarme{counts.alarms > 1 ? 's' : ''}
          </Text>
          <Button
            title="📤 Partager la séance"
            variant="secondary"
            onPress={() => shareDetector(counts)}
            style={{ marginTop: 12 }}
          />
        </Card>
      )}

      <Body style={{ color: colors.muted, fontSize: 13 }}>
        Le détecteur réagit aux bruits courts et forts : une toux ou une porte peuvent le déclencher. Le son est
        analysé en direct sur ton téléphone, jamais enregistré ni envoyé. Il s'arrête dès que tu quittes cet
        écran. Pense à monter le volume du téléphone pour la sirène.
      </Body>
    </ScrollView>
  );
}
