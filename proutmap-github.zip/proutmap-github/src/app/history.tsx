/**
 * 📜 Historique : la liste de mes prouts (ou de ceux reçus), avec recherche et filtres
 * par type, période et lieu. Toucher un prout : voir sur la carte, partager, supprimer.
 */
import { router, useFocusEffect } from 'expo-router';
import { useCallback, useMemo, useState, type ReactNode } from 'react';
import { Alert, FlatList, Pressable, ScrollView, Text, TextInput, View } from 'react-native';

import { Body, Card, Chip, styles } from '@/components/ui';
import { deleteFart, visibleFarts } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { listPlaces, placeFor, placeLabel, type Place } from '@/lib/places';
import { shareFart } from '@/lib/share';
import { colors } from '@/lib/theme';
import { KINDS, kindInfo, type Fart, type FartKind } from '@/lib/types';

type Who = 'moi' | 'recus';
type Period = 'tout' | 'jour' | '7j' | '30j' | 'annee';
const PERIODS: { value: Period; label: string }[] = [
  { value: 'tout', label: 'Tout' },
  { value: 'jour', label: "Aujourd'hui" },
  { value: '7j', label: '7 jours' },
  { value: '30j', label: '30 jours' },
  { value: 'annee', label: 'Cette année' },
];

function periodStart(p: Period): Date | null {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (p === 'jour') return today;
  if (p === '7j') return new Date(today.getTime() - 6 * 86400000);
  if (p === '30j') return new Date(today.getTime() - 29 * 86400000);
  if (p === 'annee') return new Date(now.getFullYear(), 0, 1);
  return null;
}

/** Enlève accents et majuscules pour une recherche tolérante */
const norm = (s: string) =>
  s
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase();

export default function History() {
  const { session } = useAuth();
  const me = session!.user.id;
  const [all, setAll] = useState<Fart[]>([]);
  const [places, setPlaces] = useState<Place[]>([]);
  const [who, setWho] = useState<Who>('moi');
  const [query, setQuery] = useState('');
  const [kind, setKind] = useState<FartKind | null>(null);
  const [period, setPeriod] = useState<Period>('tout');
  const [placeId, setPlaceId] = useState<string | null>(null); // 'ailleurs' = hors de mes lieux

  const load = useCallback(() => {
    visibleFarts().then(setAll).catch(() => {});
    listPlaces().then(setPlaces);
  }, []);
  useFocusEffect(load);

  const shown = useMemo(() => {
    const start = periodStart(period);
    const q = norm(query.trim());
    return all
      .filter((f) => (who === 'moi' ? f.user_id === me : f.victim_id === me))
      .map((f) => ({ f, place: placeFor(f.lat, f.lng, places) }))
      .filter(({ f, place }) => {
        if (kind && f.kind !== kind) return false;
        if (start && new Date(f.created_at) < start) return false;
        if (placeId === 'ailleurs' && place) return false;
        if (placeId && placeId !== 'ailleurs' && place?.id !== placeId) return false;
        if (q) {
          const k = kindInfo(f.kind);
          const text = [
            f.note,
            f.victim_name,
            f.author?.display_name,
            place?.name,
            k.label,
            k.badge,
            new Date(f.created_at).toLocaleDateString('fr-FR'),
          ]
            .filter(Boolean)
            .join(' ');
          if (!norm(text).includes(q)) return false;
        }
        return true;
      });
  }, [all, places, who, query, kind, period, placeId, me]);

  function onPress(f: Fart) {
    const mine = f.user_id === me;
    Alert.alert(`${kindInfo(f.kind).emoji} ${kindInfo(f.kind).label}`, new Date(f.created_at).toLocaleString('fr-FR'), [
      { text: 'Fermer', style: 'cancel' },
      { text: '🗺️ Voir sur la carte', onPress: () => router.navigate({ pathname: '/', params: { focus: String(f.id) } }) },
      ...(mine
        ? [
            { text: '📤 Partager', onPress: () => shareFart(f) },
            {
              text: 'Supprimer',
              style: 'destructive' as const,
              onPress: async () => {
                await deleteFart(f.id);
                setAll((a) => a.filter((x) => x.id !== f.id));
              },
            },
          ]
        : []),
    ]);
  }

  const chipsRow = (children: ReactNode) => (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingHorizontal: 16 }}>
      {children}
    </ScrollView>
  );

  return (
    <FlatList
      data={shown}
      keyExtractor={({ f }) => String(f.id)}
      contentContainerStyle={{ paddingBottom: 48, gap: 10 }}
      keyboardShouldPersistTaps="handled"
      ListHeaderComponent={
        <View style={{ gap: 10, paddingTop: 16 }}>
          <View style={{ paddingHorizontal: 16 }}>
            <TextInput
              style={styles.input}
              placeholder="🔎 Chercher (note, lieu, victime, date…)"
              placeholderTextColor={colors.muted}
              value={query}
              onChangeText={setQuery}
              clearButtonMode="while-editing"
            />
          </View>
          {chipsRow(
            <>
              <Chip label="💨 Les miens" selected={who === 'moi'} onPress={() => setWho('moi')} />
              <Chip label="😱 Reçus" selected={who === 'recus'} onPress={() => setWho('recus')} />
            </>,
          )}
          {chipsRow(
            PERIODS.map((p) => (
              <Chip key={p.value} label={p.label} selected={period === p.value} onPress={() => setPeriod(p.value)} />
            )),
          )}
          {chipsRow(
            <>
              <Chip label="Tous types" selected={!kind} onPress={() => setKind(null)} />
              {KINDS.map((k) => (
                <Chip
                  key={k.value}
                  label={`${k.emoji} ${k.label}`}
                  selected={kind === k.value}
                  onPress={() => setKind(k.value)}
                />
              ))}
            </>,
          )}
          {places.length > 0 &&
            chipsRow(
              <>
                <Chip label="Tous lieux" selected={!placeId} onPress={() => setPlaceId(null)} />
                {places.map((p) => (
                  <Chip key={p.id} label={placeLabel(p)} selected={placeId === p.id} onPress={() => setPlaceId(p.id)} />
                ))}
                <Chip label="🌍 Ailleurs" selected={placeId === 'ailleurs'} onPress={() => setPlaceId('ailleurs')} />
              </>,
            )}
          <Body style={{ color: colors.muted, paddingHorizontal: 16 }}>
            {shown.length} prout{shown.length > 1 ? 's' : ''}
            {places.length === 0 ? ' · Astuce : ajoute tes lieux avec 📌 sur la carte' : ''}
          </Body>
        </View>
      }
      renderItem={({ item: { f, place } }) => {
        const k = kindInfo(f.kind);
        const victim = f.victim_name ?? (f.victim_id && f.victim_id !== me ? 'un ami' : null);
        return (
          <Pressable onPress={() => onPress(f)} style={{ paddingHorizontal: 16 }}>
            <Card style={{ flexDirection: 'row', gap: 12, alignItems: 'center', padding: 12 }}>
              <Text style={{ fontSize: 30 }}>{k.emoji}</Text>
              <View style={{ flex: 1, gap: 2 }}>
                <Text style={{ fontWeight: '800', color: colors.text, fontSize: 16 }}>
                  {who === 'recus' ? `${f.author?.display_name ?? 'Un ami'} · ` : ''}
                  {k.label}
                  {k.badge ? '  😬' : ''}
                </Text>
                <Text style={{ color: colors.muted, fontSize: 13 }}>
                  {new Date(f.created_at).toLocaleString('fr-FR', { dateStyle: 'medium', timeStyle: 'short' })}
                  {place ? ` · ${placeLabel(place)}` : ''}
                </Text>
                <Text style={{ color: colors.text, fontSize: 13 }}>
                  💪 {f.power} · 🤢 {f.smell} · 🥷 {f.discretion}
                  {victim ? ` · 😈 ${victim}` : ''}
                </Text>
                {f.note ? (
                  <Text style={{ color: colors.text, fontStyle: 'italic', fontSize: 13 }} numberOfLines={2}>
                    « {f.note} »
                  </Text>
                ) : null}
              </View>
            </Card>
          </Pressable>
        );
      }}
      ListEmptyComponent={
        <Body style={{ color: colors.muted, textAlign: 'center', marginTop: 24 }}>Aucun prout ne correspond.</Body>
      }
    />
  );
}
