import { router, useLocalSearchParams } from 'expo-router';
import { useState } from 'react';
import { Alert, ScrollView, TextInput, View } from 'react-native';

import { Body, Button, Card, Chip, Label, styles } from '@/components/ui';
import { addPlace, PLACE_KINDS, type PlaceKind } from '@/lib/places';
import { colors } from '@/lib/theme';

/** Enregistrer un lieu (Maison, Boulot…) à l'endroit visé sur la carte */
export default function NewPlace() {
  const { lat, lng } = useLocalSearchParams<{ lat: string; lng: string }>();
  const [kind, setKind] = useState<PlaceKind>('maison');
  const [name, setName] = useState('Maison');
  const [touched, setTouched] = useState(false);

  function pickKind(k: PlaceKind) {
    setKind(k);
    // Propose le nom du type tant que l'utilisateur n'a rien écrit lui-même
    if (!touched) setName(k === 'pote' ? 'Chez ' : (PLACE_KINDS.find((x) => x.value === k)?.label ?? ''));
  }

  async function save() {
    if (!name.trim()) {
      Alert.alert('Donne un nom à ce lieu');
      return;
    }
    await addPlace({ name, kind, lat: Number(lat), lng: Number(lng) });
    router.back();
  }

  return (
    <ScrollView contentContainerStyle={{ padding: 16, gap: 16 }}>
      <Card>
        <Label>Type de lieu</Label>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
          {PLACE_KINDS.map((k) => (
            <Chip key={k.value} label={`${k.emoji} ${k.label}`} selected={kind === k.value} onPress={() => pickKind(k.value)} />
          ))}
        </View>
      </Card>

      <Card>
        <Label>Nom</Label>
        <TextInput
          style={[styles.input, { marginTop: 8 }]}
          value={name}
          onChangeText={(t) => {
            setName(t);
            setTouched(true);
          }}
          maxLength={30}
          placeholder="Ex. Chez Kévin, La salle de sport…"
          placeholderTextColor={colors.muted}
        />
      </Card>

      <Body style={{ color: colors.muted, fontSize: 13 }}>
        Tes prouts à moins de 100 m de ce lieu y seront rattachés (carte, historique). Tes lieux restent sur ton
        téléphone : tes amis ne les voient pas.
      </Body>

      <Button title="📌 Enregistrer le lieu" onPress={save} />
    </ScrollView>
  );
}
