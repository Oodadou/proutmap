/**
 * 📚 Ma sonothèque : tous mes sons (enregistrés ou importés) au même endroit.
 * Chaque son peut être attribué à un ou plusieurs pets / moments, renommé, envoyé, supprimé.
 */
import { useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';
import { Alert, Pressable, ScrollView, Text, TextInput, View } from 'react-native';

import { AddSound } from '@/components/add-sound';
import { Body, Button, Card, Chip, Label, styles } from '@/components/ui';
import {
  assignSound,
  deleteSound,
  getSoundPrefs,
  MAX_LIBRARY,
  playItem,
  renameSound,
  shareSound,
  slotInfo,
  SLOTS,
  usageOf,
  type SoundItem,
  type SoundPrefs,
} from '@/lib/sounds';
import { colors } from '@/lib/theme';

export default function Library() {
  const [prefs, setPrefs] = useState<SoundPrefs | null>(null);
  const [editing, setEditing] = useState<{ id: string; label: string } | null>(null);
  const [assigning, setAssigning] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setPrefs(JSON.parse(JSON.stringify(await getSoundPrefs())));
  }, []);
  useFocusEffect(
    useCallback(() => {
      refresh();
    }, [refresh]),
  );

  function more(it: SoundItem) {
    Alert.alert(it.label, undefined, [
      { text: 'Fermer', style: 'cancel' },
      { text: '✏️ Renommer', onPress: () => setEditing({ id: it.id, label: it.label }) },
      {
        text: '📤 Envoyer à mes potes',
        onPress: async () => {
          const ok = await shareSound(it.id).catch(() => false);
          if (!ok) Alert.alert('Partage impossible', "Le partage de fichiers n'est pas disponible sur ce téléphone.");
        },
      },
      {
        text: 'Supprimer',
        style: 'destructive',
        onPress: () =>
          Alert.alert(`Supprimer « ${it.label} » ?`, 'Il sera retiré de tous les pets qui l’utilisent.', [
            { text: 'Annuler', style: 'cancel' },
            {
              text: 'Supprimer',
              style: 'destructive',
              onPress: async () => {
                await deleteSound(it.id);
                refresh();
              },
            },
          ]),
      },
    ]);
  }

  async function saveName() {
    if (editing?.label.trim()) await renameSound(editing.id, editing.label);
    setEditing(null);
    refresh();
  }

  const library = prefs?.library ?? [];

  return (
    <ScrollView contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 48 }} keyboardShouldPersistTaps="handled">
      <Body style={{ color: colors.muted }}>
        Ta banque de sons : enregistre ou importe un son une fois, puis attribue-le aux pets que tu veux. Un même son
        peut servir à plusieurs pets.
      </Body>

      <AddSound onAdded={refresh} />

      <Card>
        <Label>
          Mes sons ({library.length}/{MAX_LIBRARY})
        </Label>
        {library.length === 0 && (
          <Body style={{ color: colors.muted, marginTop: 8 }}>Aucun son pour le moment. Enregistre ton premier chef-d'œuvre !</Body>
        )}
        {[...library].reverse().map((it) => {
          const used = prefs ? usageOf(it.id, prefs) : [];
          return (
            <View key={it.id} style={{ borderTopWidth: 1, borderTopColor: colors.border, paddingVertical: 10, gap: 6 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <Pressable onPress={() => playItem(it.id)} hitSlop={8} accessibilityLabel="Écouter">
                  <Text style={{ fontSize: 22 }}>▶️</Text>
                </Pressable>
                {editing?.id === it.id ? (
                  <View style={{ flex: 1, flexDirection: 'row', gap: 8 }}>
                    <TextInput
                      style={[styles.input, { flex: 1, paddingVertical: 8 }]}
                      value={editing.label}
                      onChangeText={(t) => setEditing((e) => (e ? { ...e, label: t } : e))}
                      maxLength={40}
                      autoFocus
                      onSubmitEditing={saveName}
                    />
                    <Button title="OK" onPress={saveName} />
                  </View>
                ) : (
                  <Pressable style={{ flex: 1 }} onPress={() => more(it)}>
                    <Text style={{ fontWeight: '800', color: colors.text, fontSize: 15 }}>🎤 {it.label}</Text>
                    <Text style={{ color: used.length ? colors.primaryDark : colors.muted, fontSize: 13 }} numberOfLines={2}>
                      {used.length
                        ? used.map((s) => `${slotInfo(s).emoji} ${slotInfo(s).short}`).join(' · ')
                        : 'Pas encore attribué'}
                    </Text>
                  </Pressable>
                )}
                <Pressable onPress={() => setAssigning(assigning === it.id ? null : it.id)} hitSlop={8}>
                  <Text style={{ color: colors.primaryDark, fontWeight: '800' }}>
                    {assigning === it.id ? 'Fermer' : 'Attribuer'}
                  </Text>
                </Pressable>
                <Pressable onPress={() => more(it)} hitSlop={8} accessibilityLabel="Plus d'options">
                  <Text style={{ fontSize: 20, color: colors.muted }}>⋯</Text>
                </Pressable>
              </View>
              {assigning === it.id && (
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 4 }}>
                  {SLOTS.map((s) => (
                    <Chip
                      key={s.slot}
                      label={`${s.emoji} ${s.short}`}
                      selected={used.includes(s.slot)}
                      onPress={async () => {
                        await assignSound(it.id, s.slot, !used.includes(s.slot));
                        refresh();
                      }}
                    />
                  ))}
                </View>
              )}
            </View>
          );
        })}
      </Card>

      <Body style={{ color: colors.muted, fontSize: 13 }}>
        Un son reçu d'un pote : enregistre-le sur ton téléphone puis « Importer un son ». Tes sons restent sur ton
        téléphone et sont coupés au bout de 6 secondes. Extraits de films ou de séries : usage perso uniquement (droits
        d'auteur).
      </Body>
    </ScrollView>
  );
}
