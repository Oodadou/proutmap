/**
 * Réglage d'un pet / moment : quel son joue (d'origine, un son de ma sonothèque, ou au hasard),
 * et quels sons de la sonothèque lui sont attribués.
 */
import { router, Stack, useFocusEffect, useLocalSearchParams } from 'expo-router';
import { useCallback, useState, type ReactNode } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';

import { AddSound } from '@/components/add-sound';
import { Body, Button, Card, Label } from '@/components/ui';
import {
  assignSound,
  getSoundPrefs,
  playItem,
  playSlot,
  setActive,
  slotInfo,
  slotItems,
  slotPrefs,
  SLOTS,
  type SoundPrefs,
  type SoundSlot,
} from '@/lib/sounds';
import { colors } from '@/lib/theme';

/** Ligne à choix unique (bouton radio) */
function Choice({
  selected,
  label,
  onSelect,
  onPlay,
  right,
}: {
  selected: boolean;
  label: string;
  onSelect: () => void;
  onPlay?: () => void;
  right?: ReactNode;
}) {
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        borderTopWidth: 1,
        borderTopColor: colors.border,
        paddingVertical: 10,
      }}>
      <Pressable onPress={onSelect} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 }} hitSlop={6}>
        <View
          style={{
            width: 22,
            height: 22,
            borderRadius: 11,
            borderWidth: 2,
            borderColor: selected ? colors.primary : colors.border,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          {selected && <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: colors.primary }} />}
        </View>
        <Text style={{ flex: 1, color: colors.text, fontWeight: selected ? '800' : '500', fontSize: 15 }}>{label}</Text>
      </Pressable>
      {onPlay && (
        <Pressable onPress={onPlay} hitSlop={8} accessibilityLabel="Écouter">
          <Text style={{ fontSize: 20 }}>▶️</Text>
        </Pressable>
      )}
      {right}
    </View>
  );
}

export default function SoundSlotScreen() {
  const params = useLocalSearchParams<{ slot: string }>();
  const slot = (SLOTS.some((s) => s.slot === params.slot) ? params.slot : 'classique') as SoundSlot;
  const info = slotInfo(slot);
  const [prefs, setPrefs] = useState<SoundPrefs | null>(null);

  const refresh = useCallback(async () => {
    setPrefs(JSON.parse(JSON.stringify(await getSoundPrefs())));
  }, []);
  useFocusEffect(
    useCallback(() => {
      refresh();
    }, [refresh]),
  );

  const sp = prefs ? slotPrefs(slot, prefs) : { pool: [], active: 'original' };
  const items = prefs ? slotItems(slot, prefs) : [];
  const others = (prefs?.library ?? []).filter((x) => !sp.pool.includes(x.id));

  async function choose(active: string) {
    await setActive(slot, active);
    await refresh();
    if (active !== 'off') playSlot(slot); // aperçu du choix
  }

  async function toggle(id: string, on: boolean) {
    await assignSound(id, slot, on);
    refresh();
  }

  const originalLabel =
    slot === 'alarme' ? '🤖 Voix robot « Mais qui c’est qui a pété ?! »' : info.original ? `🔊 ${info.original}` : '🔇 Pas de son';

  return (
    <ScrollView contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 48 }} keyboardShouldPersistTaps="handled">
      <Stack.Screen options={{ title: `${info.emoji} ${info.short}` }} />

      <Card style={{ gap: 4 }}>
        <Text style={{ fontSize: 20, fontWeight: '900', color: colors.text }}>
          {info.emoji} {info.title}
        </Text>
        <Body style={{ color: colors.muted }}>{info.when}</Body>
      </Card>

      <Card>
        <Label>Son joué (selon ton humeur)</Label>
        <View style={{ marginTop: 8 }}>
          <Choice
            selected={sp.active === 'original'}
            label={originalLabel}
            onSelect={() => choose('original')}
            onPlay={info.original ? () => playSlot(slot, { forceOriginal: true }) : undefined}
          />
          {slot === 'alarme' && <Choice selected={sp.active === 'off'} label="🔇 Rien (sirène seule)" onSelect={() => choose('off')} />}
          {items.length >= 2 && (
            <Choice
              selected={sp.active === 'random'}
              label={`🎲 Au hasard parmi ces ${items.length} sons`}
              onSelect={() => choose('random')}
            />
          )}
          {items.map((it) => (
            <Choice
              key={it.id}
              selected={sp.active === it.id}
              label={`🎤 ${it.label}`}
              onSelect={() => choose(it.id)}
              onPlay={() => playItem(it.id)}
              right={
                <Pressable onPress={() => toggle(it.id, false)} hitSlop={8} accessibilityLabel="Retirer de ce pet">
                  <Text style={{ color: colors.muted, fontSize: 18 }}>✕</Text>
                </Pressable>
              }
            />
          ))}
        </View>
        {items.length === 0 && (
          <Body style={{ color: colors.muted, fontSize: 13, marginTop: 8 }}>
            Ajoute des sons depuis ta sonothèque ci-dessous, ou enregistres-en un nouveau.
          </Body>
        )}
      </Card>

      <Card>
        <Label>Piocher dans ma sonothèque</Label>
        {others.length === 0 ? (
          <Body style={{ color: colors.muted, marginTop: 8 }}>
            {prefs?.library.length ? 'Tous tes sons sont déjà attribués ici.' : 'Ta sonothèque est vide pour le moment.'}
          </Body>
        ) : (
          others.map((it) => (
            <View
              key={it.id}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: 10,
                borderTopWidth: 1,
                borderTopColor: colors.border,
                paddingVertical: 10,
              }}>
              <Pressable onPress={() => playItem(it.id)} hitSlop={8} accessibilityLabel="Écouter">
                <Text style={{ fontSize: 20 }}>▶️</Text>
              </Pressable>
              <Text style={{ flex: 1, color: colors.text }}>🎤 {it.label}</Text>
              <Pressable onPress={() => toggle(it.id, true)} hitSlop={8}>
                <Text style={{ color: colors.primaryDark, fontWeight: '800' }}>＋ Ajouter</Text>
              </Pressable>
            </View>
          ))
        )}
        <Button
          title="📚 Gérer ma sonothèque"
          variant="ghost"
          onPress={() => router.push('/library')}
          style={{ marginTop: 6 }}
        />
      </Card>

      <AddSound defaultSlots={[slot]} onAdded={refresh} />
    </ScrollView>
  );
}
