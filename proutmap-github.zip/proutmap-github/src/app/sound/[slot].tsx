/**
 * Réglage d'un son de la bande son : une collection de sons perso (enregistrés ou importés),
 * et le choix de celui qui joue — selon l'humeur — ou « au hasard ».
 */
import {
  RecordingPresets,
  requestRecordingPermissionsAsync,
  useAudioRecorder,
  useAudioRecorderState,
} from 'expo-audio';
import * as DocumentPicker from 'expo-document-picker';
import * as Haptics from 'expo-haptics';
import { Stack, useLocalSearchParams } from 'expo-router';
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Alert, Pressable, ScrollView, Text, TextInput, View } from 'react-native';

import { Body, Button, Card, Label, styles } from '@/components/ui';
import {
  addSound,
  deleteSound,
  getSoundPrefs,
  MAX_SOUNDS_PER_SLOT,
  playItem,
  playSlot,
  renameSound,
  resetAudioMode,
  setActive,
  setMicMode,
  shareSound,
  slotInfo,
  slotPrefs,
  SLOTS,
  type SlotPrefs,
  type SoundItem,
  type SoundSlot,
} from '@/lib/sounds';
import { colors } from '@/lib/theme';

const MAX_REC_SEC = 5;
const MAX_IMPORT_MB = 3;

/** Ligne à choix unique (bouton radio) */
function Choice({
  selected,
  label,
  onSelect,
  onPlay,
  children,
}: {
  selected: boolean;
  label: string;
  onSelect: () => void;
  onPlay?: () => void;
  children?: ReactNode;
}) {
  return (
    <View style={{ borderTopWidth: 1, borderTopColor: colors.border, paddingVertical: 10 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <Pressable onPress={onSelect} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 }} hitSlop={6}>
          <View
            style={{
              width: 22,
              height: 22,
              borderRadius: 11,
              borderWidth: 2,
              borderColor: selected ? colors.primary : colors.border,
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            {selected && <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: colors.primary }} />}
          </View>
          <Text style={{ flex: 1, color: colors.text, fontWeight: selected ? '800' : '500', fontSize: 15 }}>{label}</Text>
        </Pressable>
        {onPlay && (
          <Pressable onPress={onPlay} hitSlop={8} accessibilityLabel="Écouter">
            <Text style={{ fontSize: 20 }}>▶️</Text>
          </Pressable>
        )}
      </View>
      {children}
    </View>
  );
}

export default function SoundSlotScreen() {
  const params = useLocalSearchParams<{ slot: string }>();
  const slot = (SLOTS.some((s) => s.slot === params.slot) ? params.slot : 'classique') as SoundSlot;
  const info = slotInfo(slot);

  const [sp, setSp] = useState<SlotPrefs>({ items: [], active: 'original' });
  const [editing, setEditing] = useState<{ id: string; label: string } | null>(null);
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const rec = useAudioRecorderState(recorder, 200);
  const [recording, setRecording] = useState(false);
  const stopTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const refresh = async () => {
    const p = await getSoundPrefs();
    const cur = slotPrefs(slot, p);
    setSp({ items: [...cur.items], active: cur.active });
  };
  useEffect(() => {
    refresh();
    return () => {
      if (stopTimer.current) clearTimeout(stopTimer.current);
      resetAudioMode();
    };
  }, []);

  async function choose(active: string) {
    await setActive(slot, active);
    await refresh();
    if (active !== 'off') playSlot(slot); // aperçu du choix
  }

  async function startRecording() {
    if (sp.items.length >= MAX_SOUNDS_PER_SLOT) {
      Alert.alert('Collection pleine', `Maximum ${MAX_SOUNDS_PER_SLOT} sons ici : supprimes-en un d'abord.`);
      return;
    }
    const perm = await requestRecordingPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Micro refusé', 'Autorise le micro dans les réglages du téléphone pour enregistrer.');
      return;
    }
    try {
      await setMicMode(true);
      await recorder.prepareToRecordAsync();
      recorder.record();
      setRecording(true);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
      stopTimer.current = setTimeout(stopRecording, MAX_REC_SEC * 1000);
    } catch (e: any) {
      setRecording(false);
      Alert.alert("Impossible d'enregistrer", e?.message ?? String(e));
    }
  }

  async function stopRecording() {
    if (stopTimer.current) clearTimeout(stopTimer.current);
    stopTimer.current = null;
    try {
      await recorder.stop();
      setRecording(false);
      await setMicMode(false);
      if (!recorder.uri) throw new Error('Enregistrement introuvable');
      const id = await addSound(slot, recorder.uri, 'm4a', `Son n°${sp.items.length + 1}`);
      await refresh();
      playItem(slot, id); // on réécoute tout de suite
      setEditing({ id, label: '' }); // et on propose de lui donner un nom
    } catch (e: any) {
      setRecording(false);
      Alert.alert("L'enregistrement a échoué", e?.message ?? String(e));
    }
  }

  async function importSound() {
    const res = await DocumentPicker.getDocumentAsync({ type: 'audio/*', copyToCacheDirectory: true });
    if (res.canceled) return;
    const a = res.assets[0];
    if (a.size && a.size > MAX_IMPORT_MB * 1024 * 1024) {
      Alert.alert('Son trop lourd', `Choisis un extrait court (moins de ${MAX_IMPORT_MB} Mo, quelques secondes).`);
      return;
    }
    try {
      const ext = a.name.includes('.') ? a.name.split('.').pop()! : 'm4a';
      const id = await addSound(slot, a.uri, ext, a.name.replace(/\.[^.]+$/, ''));
      await refresh();
      playItem(slot, id);
    } catch (e: any) {
      Alert.alert("Impossible d'importer ce son", e?.message ?? String(e));
    }
  }

  function more(it: SoundItem) {
    Alert.alert(it.label, undefined, [
      { text: 'Fermer', style: 'cancel' },
      { text: '✏️ Renommer', onPress: () => setEditing({ id: it.id, label: it.label }) },
      {
        text: '📤 Envoyer à mes potes',
        onPress: async () => {
          const ok = await shareSound(slot, it.id).catch(() => false);
          if (!ok) Alert.alert('Partage impossible', "Le partage de fichiers n'est pas disponible sur ce téléphone.");
        },
      },
      {
        text: 'Supprimer',
        style: 'destructive',
        onPress: async () => {
          await deleteSound(slot, it.id);
          refresh();
        },
      },
    ]);
  }

  async function saveName() {
    if (!editing) return;
    if (editing.label.trim()) await renameSound(slot, editing.id, editing.label);
    setEditing(null);
    refresh();
  }

  const originalLabel =
    slot === 'alarme' ? '🤖 Voix robot « Mais qui c’est qui a pété ?! »' : info.original ? `🔊 ${info.original}` : '🔇 Pas de son';
  const secs = Math.min(MAX_REC_SEC, Math.floor((rec.durationMillis ?? 0) / 1000));

  return (
    <ScrollView contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 48 }} keyboardShouldPersistTaps="handled">
      <Stack.Screen options={{ title: `${info.emoji} Son` }} />

      <Card style={{ gap: 4 }}>
        <Text style={{ fontSize: 20, fontWeight: '900', color: colors.text }}>
          {info.emoji} {info.title}
        </Text>
        <Body style={{ color: colors.muted }}>{info.when}</Body>
      </Card>

      <Card>
        <Label>Son joué (selon ton humeur)</Label>
        <View style={{ marginTop: 8 }}>
          <Choice
            selected={sp.active === 'original'}
            label={originalLabel}
            onSelect={() => choose('original')}
            onPlay={info.original ? () => playSlot(slot, { forceOriginal: true }) : undefined}
          />
          {slot === 'alarme' && <Choice selected={sp.active === 'off'} label="🔇 Rien (sirène seule)" onSelect={() => choose('off')} />}
          {sp.items.length >= 2 && (
            <Choice
              selected={sp.active === 'random'}
              label={`🎲 Au hasard parmi mes ${sp.items.length} sons`}
              onSelect={() => choose('random')}
            />
          )}
          {sp.items.map((it) => (
            <Choice
              key={it.id}
              selected={sp.active === it.id}
              label={`🎤 ${it.label}`}
              onSelect={() => choose(it.id)}
              onPlay={() => playItem(slot, it.id)}>
              {editing?.id === it.id ? (
                <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
                  <TextInput
                    style={[styles.input, { flex: 1, paddingVertical: 8 }]}
                    value={editing.label}
                    onChangeText={(t) => setEditing({ ...editing, label: t })}
                    placeholder="Nom du son (ex. Prout de l'enfer)"
                    placeholderTextColor={colors.muted}
                    maxLength={40}
                    autoFocus
                    onSubmitEditing={saveName}
                  />
                  <Button title="OK" onPress={saveName} />
                </View>
              ) : (
                <Pressable onPress={() => more(it)} hitSlop={6} style={{ marginLeft: 32, marginTop: 4 }}>
                  <Text style={{ color: colors.primaryDark, fontWeight: '700' }}>Renommer · Envoyer · Supprimer</Text>
                </Pressable>
              )}
            </Choice>
          ))}
        </View>
      </Card>

      <Card style={{ gap: 12 }}>
        <Label>
          Ajouter un son ({sp.items.length}/{MAX_SOUNDS_PER_SLOT})
        </Label>
        {recording ? (
          <>
            <Text style={{ fontSize: 22, fontWeight: '900', color: colors.danger, textAlign: 'center' }}>
              ⏺ Enregistrement… {secs} / {MAX_REC_SEC} s
            </Text>
            <Button title="⏹ Arrêter" variant="danger" onPress={stopRecording} />
          </>
        ) : (
          <>
            <Button title="⏺ Enregistrer un nouveau son (5 s max)" onPress={startRecording} />
            <Button title="📁 Importer un son du téléphone" variant="secondary" onPress={importSound} />
          </>
        )}
      </Card>

      <Body style={{ color: colors.muted, fontSize: 13 }}>
        Un son reçu d'un pote : enregistre-le sur ton téléphone, puis « Importer un son ». Tes sons restent sur ton
        téléphone et sont coupés au bout de 6 secondes. Pour un extrait de film ou de série : usage perso uniquement
        (droits d'auteur), l'appli ne peut pas en fournir.
      </Body>
    </ScrollView>
  );
}
