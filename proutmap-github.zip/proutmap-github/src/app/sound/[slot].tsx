/**
 * Réglage d'un son de la bande son : écouter, enregistrer sa voix, importer un son,
 * l'envoyer à ses potes, ou revenir au son d'origine.
 */
import {
  RecordingPresets,
  requestRecordingPermissionsAsync,
  useAudioRecorder,
  useAudioRecorderState,
} from 'expo-audio';
import * as DocumentPicker from 'expo-document-picker';
import * as Haptics from 'expo-haptics';
import { Stack, useLocalSearchParams } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import { Alert, ScrollView, Text, View } from 'react-native';

import { Body, Button, Card, Chip, Label } from '@/components/ui';
import {
  getSoundPrefs,
  playSlot,
  resetAudioMode,
  resetSlot,
  setAlarmMode,
  setCustomSound,
  setMicMode,
  shareSlot,
  slotInfo,
  slotLabel,
  SLOTS,
  type SoundPrefs,
  type SoundSlot,
} from '@/lib/sounds';
import { colors } from '@/lib/theme';

const MAX_REC_SEC = 5;
const MAX_IMPORT_MB = 3;

export default function SoundSlotScreen() {
  const params = useLocalSearchParams<{ slot: string }>();
  const slot = (SLOTS.some((s) => s.slot === params.slot) ? params.slot : 'classique') as SoundSlot;
  const info = slotInfo(slot);

  const [prefs, setPrefs] = useState<SoundPrefs | null>(null);
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const rec = useAudioRecorderState(recorder, 200);
  const [recording, setRecording] = useState(false);
  const stopTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const refresh = async () => setPrefs({ ...(await getSoundPrefs()) });
  useEffect(() => {
    refresh();
    return () => {
      if (stopTimer.current) clearTimeout(stopTimer.current);
      resetAudioMode();
    };
  }, []);

  const custom = prefs?.custom[slot];

  async function startRecording() {
    const perm = await requestRecordingPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Micro refusé', 'Autorise le micro dans les réglages du téléphone pour enregistrer.');
      return;
    }
    try {
      await setMicMode(true);
      await recorder.prepareToRecordAsync();
      recorder.record();
      setRecording(true);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
      stopTimer.current = setTimeout(stopRecording, MAX_REC_SEC * 1000);
    } catch (e: any) {
      setRecording(false);
      Alert.alert("Impossible d'enregistrer", e?.message ?? String(e));
    }
  }

  async function stopRecording() {
    if (stopTimer.current) clearTimeout(stopTimer.current);
    stopTimer.current = null;
    try {
      await recorder.stop();
      setRecording(false);
      await setMicMode(false);
      if (!recorder.uri) throw new Error('Enregistrement introuvable');
      await setCustomSound(slot, recorder.uri, 'm4a', `Mon son (${new Date().toLocaleDateString('fr-FR')})`);
      await refresh();
      playSlot(slot); // on réécoute tout de suite
    } catch (e: any) {
      setRecording(false);
      Alert.alert("L'enregistrement a échoué", e?.message ?? String(e));
    }
  }

  async function importSound() {
    const res = await DocumentPicker.getDocumentAsync({ type: 'audio/*', copyToCacheDirectory: true });
    if (res.canceled) return;
    const a = res.assets[0];
    if (a.size && a.size > MAX_IMPORT_MB * 1024 * 1024) {
      Alert.alert('Son trop lourd', `Choisis un extrait court (moins de ${MAX_IMPORT_MB} Mo, quelques secondes).`);
      return;
    }
    try {
      const ext = a.name.includes('.') ? a.name.split('.').pop()! : 'm4a';
      await setCustomSound(slot, a.uri, ext, a.name.replace(/\.[^.]+$/, ''));
      await refresh();
      playSlot(slot);
    } catch (e: any) {
      Alert.alert("Impossible d'importer ce son", e?.message ?? String(e));
    }
  }

  async function share() {
    const ok = await shareSlot(slot).catch(() => false);
    if (!ok) Alert.alert('Partage impossible', "Le partage de fichiers n'est pas disponible sur ce téléphone.");
  }

  async function backToOriginal() {
    Alert.alert('Revenir au son d’origine ?', 'Ton son perso sera supprimé de ce téléphone.', [
      { text: 'Annuler', style: 'cancel' },
      {
        text: 'Revenir',
        style: 'destructive',
        onPress: async () => {
          await resetSlot(slot);
          refresh();
        },
      },
    ]);
  }

  const secs = Math.min(MAX_REC_SEC, Math.floor((rec.durationMillis ?? 0) / 1000));

  return (
    <ScrollView contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 48 }}>
      <Stack.Screen options={{ title: `${info.emoji} Son` }} />

      <Card style={{ gap: 6 }}>
        <Text style={{ fontSize: 20, fontWeight: '900', color: colors.text }}>
          {info.emoji} {info.title}
        </Text>
        <Body style={{ color: colors.muted }}>{info.when}</Body>
        <Body style={{ marginTop: 6 }}>Actuellement : {prefs ? slotLabel(slot, prefs) : '…'}</Body>
        <Button title="▶️ Écouter" variant="secondary" onPress={() => playSlot(slot)} style={{ marginTop: 6 }} />
      </Card>

      {slot === 'alarme' && prefs && (
        <Card>
          <Label>Après la sirène</Label>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
            <Chip
              label="🤖 Voix robot"
              selected={prefs.alarmMode === 'robot'}
              onPress={async () => {
                await setAlarmMode('robot');
                await refresh();
                playSlot('alarme');
              }}
            />
            <Chip
              label="🎤 Mon son"
              selected={prefs.alarmMode === 'perso'}
              onPress={async () => {
                if (!custom) return Alert.alert('Pas encore de son perso', 'Enregistre ou importe un son juste en dessous.');
                await setAlarmMode('perso');
                await refresh();
                playSlot('alarme');
              }}
            />
            <Chip
              label="🔇 Rien"
              selected={prefs.alarmMode === 'off'}
              onPress={async () => {
                await setAlarmMode('off');
                refresh();
              }}
            />
          </View>
        </Card>
      )}

      <Card style={{ gap: 12 }}>
        <Label>Mon son perso</Label>
        <Body>{custom ? `🎤 ${custom.label}` : 'Aucun pour le moment.'}</Body>

        {recording ? (
          <>
            <Text style={{ fontSize: 22, fontWeight: '900', color: colors.danger, textAlign: 'center' }}>
              ⏺ Enregistrement… {secs} / {MAX_REC_SEC} s
            </Text>
            <Button title="⏹ Arrêter" variant="danger" onPress={stopRecording} />
          </>
        ) : (
          <>
            <Button title="⏺ Enregistrer (5 s max)" onPress={startRecording} />
            <Button title="📁 Importer un son du téléphone" variant="secondary" onPress={importSound} />
            {custom && (
              <>
                <Button title="📤 Envoyer à mes potes (WhatsApp, groupes…)" onPress={share} />
                <Button title="↩️ Revenir au son d’origine" variant="ghost" onPress={backToOriginal} />
              </>
            )}
          </>
        )}
      </Card>

      <Body style={{ color: colors.muted, fontSize: 13 }}>
        Un son reçu d'un pote : enregistre-le sur ton téléphone, puis « Importer un son ». Les sons perso restent sur
        ton téléphone et sont coupés au bout de 6 secondes. Pour un extrait de film ou de série : usage perso uniquement
        (droits d'auteur), l'appli ne peut pas en fournir.
      </Body>
    </ScrollView>
  );
}
