import { useEffect, useRef, useState, type ComponentType } from 'react';
import { StyleSheet } from 'react-native';
import { WebView, type WebViewMessageEvent } from 'react-native-webview';

// Les types de WebView ne suivent pas encore React 19 : on les assouplit ici
const WV = WebView as unknown as ComponentType<any>;

import { kindInfo, type Fart } from '@/lib/types';

/**
 * Carte MapLibre (cartes « vectorielles ») dans une WebView, même rendu sur iPhone et Android.
 *
 * Fond : OpenFreeMap (https://openfreemap.org), gratuit, sans clé, sans limite, usage commercial
 * autorisé (financé par les dons : penser à les soutenir si l'appli rapporte).
 * La carte est recolorée ici aux couleurs de l'appli (crème, vert, bleu doux) et allégée
 * (pas de commerces ni d'arrêts de bus) : voir friendly() plus bas.
 *
 * Pour changer de fournisseur plus tard : mettre l'adresse d'un style MapLibre dans
 * EXPO_PUBLIC_MAP_STYLE_URL (la recoloration est alors désactivée).
 */
const STYLE_URL = process.env.EXPO_PUBLIC_MAP_STYLE_URL || 'https://tiles.openfreemap.org/styles/positron';
const FRIENDLY = !process.env.EXPO_PUBLIC_MAP_STYLE_URL;
const MAPLIBRE = 'https://unpkg.com/maplibre-gl@5.24.1/dist';

const HTML = `<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="stylesheet" href="${MAPLIBRE}/maplibre-gl.css"/>
<script src="${MAPLIBRE}/maplibre-gl.js"></script>
<style>
 html,body,#map{margin:0;height:100%;background:#FFF8EC}
 .pin{font-size:20px;text-align:center;cursor:pointer;filter:drop-shadow(0 2px 3px rgba(59,42,26,.35))}
 .pin span{display:block;border-radius:50%;width:36px;height:36px;line-height:31px;border:3px solid #fff;box-sizing:border-box}
 .me span{background:#7BC043}.friend span{background:#F4A62A}.victim span{background:#D9534F}
 .maplibregl-popup-content{font:14px -apple-system,Roboto,sans-serif;color:#3B2A1A;border-radius:16px;padding:12px 14px}
 .act{display:inline-block;margin-top:6px;color:#4E8A22;font-weight:700}
 .badge{display:inline-block;margin-top:4px;padding:2px 8px;border-radius:999px;background:#F4A62A;color:#fff;font-weight:800;font-size:12px}
 .you{width:16px;height:16px;border-radius:50%;background:#2a7ef4;border:3px solid #fff;box-shadow:0 0 0 6px rgba(42,126,244,.2),0 0 4px rgba(0,0,0,.4)}
</style></head><body><div id="map"></div><script>
function send(o){window.ReactNativeWebView.postMessage(JSON.stringify(o))}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
var map=new maplibregl.Map({container:'map',style:'${STYLE_URL}',center:[2.4,46.6],zoom:4.6,
  attributionControl:{compact:true},pitchWithRotate:false,dragRotate:false});
map.touchZoomRotate.disableRotation();

// Recoloration « friendly » : on garde la carte, on change l'ambiance
function sp(id,k,v){try{map.setPaintProperty(id,k,v)}catch(e){}}
function hide(id){try{map.setLayoutProperty(id,'visibility','none')}catch(e){}}
function friendly(){
  map.getStyle().layers.forEach(function(l){
    var s=l['source-layer']||'',id=l.id,t=l.type;
    if(t==='background')return sp(id,'background-color','#FFF8EC');
    if(t==='symbol'){
      if(/poi|aerodrome|mountain|housenumber/.test(s)||/poi|housenumber/.test(id))return hide(id);
      sp(id,'text-color',/water/.test(s)?'#4A9CC4':'#7A6650');sp(id,'text-halo-color','#FFF8EC');sp(id,'text-halo-width',1.5);return;
    }
    if(s==='water'&&t==='fill')return sp(id,'fill-color','#BFE6F5');
    if(s==='waterway'&&t==='line')return sp(id,'line-color','#A9DCF0');
    if((s==='park'||s==='landcover'||s==='landuse')&&t==='fill'){
      if(/wood|forest/.test(id))return sp(id,'fill-color','#CDE8B0');
      if(s==='park'||/park|grass|cemetery|pitch|garden|meadow|farm/.test(id))return sp(id,'fill-color','#DDF0C8');
      return sp(id,'fill-color','#F7EEDD');
    }
    if(s==='building'){if(t==='fill')sp(id,'fill-color','#F1E3CC');if(t==='fill-extrusion')sp(id,'fill-extrusion-color','#F1E3CC');return;}
    if(s==='transportation'&&t==='line'){
      if(/rail|transit/.test(id))return sp(id,'line-color','#E8DCC8');
      if(/casing/.test(id))return sp(id,'line-color','#EADBC3');
      return sp(id,'line-color',/motorway|trunk|primary|major/.test(id)?'#FFE0A3':'#FFFFFF');
    }
    if(s==='boundary'&&t==='line')return sp(id,'line-color','#D8C6E6');
  });
}
if(${FRIENDLY ? 'true' : 'false'})map.on('load',friendly);

var markers=[],meMarker=null,centered=false;
function pin(cls,emoji){var el=document.createElement('div');el.className='pin '+cls;el.innerHTML='<span>'+esc(emoji)+'</span>';return el;}
window.setFarts=function(list){
  markers.forEach(function(m){m.remove()});markers=[];
  list.forEach(function(f){
    var html='<b>'+esc(f.emoji+' '+f.who+' — '+f.kind)+'</b>'+(f.badge?'<br><span class="badge">'+esc(f.badge)+'</span>':'')+'<br>💪 '+f.power+'/5 · 👃 '+f.smell+'/5 · 🤫 '+f.discretion+'/5'
      +(f.victim?'<br><b>Oups, sur '+esc(f.victim)+' xD</b>':'')
      +(f.note?'<br><i>« '+esc(f.note)+' »</i>':'')
      +'<br><small>'+esc(f.date)+'</small><br><a class="act" href="#" onclick="send({action:\\'fart\\',id:'+f.id+'});return false;">'+(f.mine?'Partager / supprimer…':'Signaler…')+'</a>';
    markers.push(new maplibregl.Marker({element:pin(f.cls,f.emoji)}).setLngLat([f.lng,f.lat])
      .setPopup(new maplibregl.Popup({offset:20,closeButton:false,maxWidth:'260px'}).setHTML(html)).addTo(map));
  });
};
window.setMe=function(lat,lng){
  if(meMarker)meMarker.setLngLat([lng,lat]);
  else{var el=document.createElement('div');el.className='you';meMarker=new maplibregl.Marker({element:el}).setLngLat([lng,lat]).addTo(map);}
  if(!centered){centered=true;map.jumpTo({center:[lng,lat],zoom:14});}
};
send({action:'ready'});
</script></body></html>`;

type Props = {
  farts: Fart[];
  me: string;
  myPosition: { lat: number; lng: number } | null;
  onFartPress: (f: Fart) => void;
};

export function FartMap({ farts, me, myPosition, onFartPress }: Props) {
  const ref = useRef<{ injectJavaScript: (js: string) => void } | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!ready) return;
    const data = farts.map((f) => {
      const k = kindInfo(f.kind);
      return {
        id: f.id,
        lat: f.lat,
        lng: f.lng,
        emoji: k.emoji,
        kind: k.label,
        badge: k.badge ?? null,
        who: f.user_id === me ? 'Toi' : (f.author?.display_name ?? 'Un ami'),
        cls: f.victim_id === me ? 'victim' : f.user_id === me ? 'me' : 'friend',
        mine: f.user_id === me,
        power: f.power,
        smell: f.smell,
        discretion: f.discretion,
        note: f.note,
        victim: f.victim_id === me ? 'toi 😱' : (f.victim_name ?? (f.victim_id ? 'un ami' : null)),
        date: new Date(f.created_at).toLocaleString('fr-FR'),
      };
    });
    ref.current?.injectJavaScript(`window.setFarts(${JSON.stringify(data)});true;`);
  }, [ready, farts, me]);

  useEffect(() => {
    if (ready && myPosition) {
      ref.current?.injectJavaScript(`window.setMe(${myPosition.lat},${myPosition.lng});true;`);
    }
  }, [ready, myPosition]);

  function onMessage(e: WebViewMessageEvent) {
    try {
      const msg = JSON.parse(e.nativeEvent.data);
      if (msg.action === 'ready') setReady(true);
      if (msg.action === 'fart') {
        const f = farts.find((x) => x.id === msg.id);
        if (f) onFartPress(f);
      }
    } catch {}
  }

  return (
    <WV
      ref={ref}
      style={StyleSheet.absoluteFill}
      originWhitelist={['*']}
      source={{ html: HTML, baseUrl: 'https://proutmap.local/' }}
      onMessage={onMessage}
      javaScriptEnabled
    />
  );
}
