/**
 * Bloc « Ajouter un son à la sonothèque » : enregistrer (5 s) ou importer un fichier,
 * puis le nommer et choisir à quel(s) pet(s) / moment(s) l'attribuer.
 */
import {
  RecordingPresets,
  requestRecordingPermissionsAsync,
  useAudioRecorder,
  useAudioRecorderState,
} from 'expo-audio';
import * as DocumentPicker from 'expo-document-picker';
import * as Haptics from 'expo-haptics';
import { useEffect, useRef, useState } from 'react';
import { Alert, Text, TextInput, View } from 'react-native';

import { Body, Button, Card, Chip, Label, styles } from '@/components/ui';
import { addSound, playUri, resetAudioMode, setMicMode, SLOTS, type SoundSlot } from '@/lib/sounds';
import { colors } from '@/lib/theme';

const MAX_REC_SEC = 5;
const MAX_IMPORT_MB = 3;

type Pending = { uri: string; ext: string; label: string; slots: SoundSlot[] };

export function AddSound({
  defaultSlots = [],
  onAdded,
}: {
  /** Emplacements cochés d'office (ex. le pet dont on vient) */
  defaultSlots?: SoundSlot[];
  onAdded?: (id: string) => void;
}) {
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const rec = useAudioRecorderState(recorder, 200);
  const [recording, setRecording] = useState(false);
  const [pending, setPending] = useState<Pending | null>(null);
  const stopTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(
    () => () => {
      if (stopTimer.current) clearTimeout(stopTimer.current);
      resetAudioMode();
    },
    [],
  );

  async function startRecording() {
    const perm = await requestRecordingPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Micro refusé', 'Autorise le micro dans les réglages du téléphone pour enregistrer.');
      return;
    }
    try {
      await setMicMode(true);
      await recorder.prepareToRecordAsync();
      recorder.record();
      setRecording(true);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
      stopTimer.current = setTimeout(stopRecording, MAX_REC_SEC * 1000);
    } catch (e: any) {
      setRecording(false);
      Alert.alert("Impossible d'enregistrer", e?.message ?? String(e));
    }
  }

  async function stopRecording() {
    if (stopTimer.current) clearTimeout(stopTimer.current);
    stopTimer.current = null;
    try {
      await recorder.stop();
      setRecording(false);
      await setMicMode(false);
      if (!recorder.uri) throw new Error('Enregistrement introuvable');
      setPending({ uri: recorder.uri, ext: 'm4a', label: '', slots: defaultSlots });
      playUri(recorder.uri); // on réécoute tout de suite
    } catch (e: any) {
      setRecording(false);
      Alert.alert("L'enregistrement a échoué", e?.message ?? String(e));
    }
  }

  async function importSound() {
    const res = await DocumentPicker.getDocumentAsync({ type: 'audio/*', copyToCacheDirectory: true });
    if (res.canceled) return;
    const a = res.assets[0];
    if (a.size && a.size > MAX_IMPORT_MB * 1024 * 1024) {
      Alert.alert('Son trop lourd', `Choisis un extrait court (moins de ${MAX_IMPORT_MB} Mo, quelques secondes).`);
      return;
    }
    const ext = a.name.includes('.') ? a.name.split('.').pop()! : 'm4a';
    setPending({ uri: a.uri, ext, label: a.name.replace(/\.[^.]+$/, '').slice(0, 40), slots: defaultSlots });
    playUri(a.uri);
  }

  async function confirm() {
    if (!pending) return;
    try {
      const id = await addSound(pending.uri, pending.ext, pending.label, pending.slots);
      setPending(null);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
      onAdded?.(id);
    } catch (e: any) {
      Alert.alert("Impossible d'ajouter ce son", e?.message ?? String(e));
    }
  }

  const toggleSlot = (slot: SoundSlot) =>
    setPending((p) =>
      p ? { ...p, slots: p.slots.includes(slot) ? p.slots.filter((s) => s !== slot) : [...p.slots, slot] } : p,
    );

  const secs = Math.min(MAX_REC_SEC, Math.floor((rec.durationMillis ?? 0) / 1000));

  if (pending) {
    return (
      <Card style={{ gap: 12, borderColor: colors.primary, borderWidth: 2 }}>
        <Label>Nouveau son</Label>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <TextInput
            style={[styles.input, { flex: 1 }]}
            value={pending.label}
            onChangeText={(t) => setPending({ ...pending, label: t })}
            placeholder="Nom (ex. Prout de l'enfer, Accent marseillais…)"
            placeholderTextColor={colors.muted}
            maxLength={40}
          />
          <Button title="▶️" variant="secondary" onPress={() => playUri(pending.uri)} />
        </View>
        <Body>Pour quel(s) pet(s) ou moment(s) ? (modifiable plus tard)</Body>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {SLOTS.map((s) => (
            <Chip
              key={s.slot}
              label={`${s.emoji} ${s.short}`}
              selected={pending.slots.includes(s.slot)}
              onPress={() => toggleSlot(s.slot)}
            />
          ))}
        </View>
        <Body style={{ color: colors.muted, fontSize: 13 }}>
          Sans rien cocher, le son est simplement rangé dans ta sonothèque.
        </Body>
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Button title="Annuler" variant="ghost" style={{ flex: 1 }} onPress={() => setPending(null)} />
          <Button title="✅ Ajouter" style={{ flex: 2 }} onPress={confirm} />
        </View>
      </Card>
    );
  }

  return (
    <Card style={{ gap: 12 }}>
      <Label>Ajouter un son</Label>
      {recording ? (
        <>
          <Text style={{ fontSize: 22, fontWeight: '900', color: colors.danger, textAlign: 'center' }}>
            ⏺ Enregistrement… {secs} / {MAX_REC_SEC} s
          </Text>
          <Button title="⏹ Arrêter" variant="danger" onPress={stopRecording} />
        </>
      ) : (
        <>
          <Button title="⏺ Enregistrer un son (5 s max)" onPress={startRecording} />
          <Button title="📁 Importer un son du téléphone" variant="secondary" onPress={importSound} />
        </>
      )}
    </Card>
  );
}
